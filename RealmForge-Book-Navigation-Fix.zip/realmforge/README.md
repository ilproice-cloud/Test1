# RealmForge — Fabric 1.21.1

RealmForge is a single Fabric mod JAR. The RPG book contains all sections in one page-turning vanilla book: Player, Attributes, Stat Effects, References, Stats in Bars, then the Trait and Perk catalog pages.

## Build

Requires Java 21. GitHub Actions uses Gradle 8.8 and is configured in `.github/workflows/build.yml`.

1. Push this project (or `realmforgeUpd2.zip`) to your GitHub repository.
2. Open **Actions → Build RealmForge Fabric 1.21.1 → Run workflow**.
3. Download the `RealmForge-Fabric-1.21.1` artifact and place the single `realmforge-1.0.0.jar` in the Minecraft `mods` folder.

Do not put source archives or the project ZIP in the `mods` folder. Install Fabric Loader for Minecraft 1.21.1, Fabric API, and the RealmForge JAR.

## Controls

- `K`: open the RPG book
- `Z`, `X`, `C`, `V`: skill slots 1–4
- `/realmforge book`: open the book

Trait/perk effects are calculated through the shared player data formulas and feed into stats, damage, damage taken, EXP gain, dodge, lifesteal, skill damage, energy capacity, and energy regeneration.
