package com.realmforge.client;

import com.realmforge.data.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.BookScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.WrittenBookContentComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.*;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Main book = 4 pages (Player, Attributes, Stat Effects, References).
 * Trait book and Perk book are separate books opened only by the TRAIT / PERK buttons.
 */
public final class RpgBook {
    private static final int PER_PAGE = 2;
    private static final int BAR_LEN = 20;
    private RpgBook() { }

    // ------------------------------------------------------------------ entry points
    public static Screen screen(int startPage) { return main(startPage); }

    public static Screen main(int startPage) {
        RpgData d = ClientRpg.data;
        List<Text> pages = new ArrayList<>();
        pages.add(playerPage(d, playerName()));
        pages.add(attributesPage(d));
        pages.add(effectsPage(d));
        pages.add(referencesPage(d));
        return make(pages, startPage);
    }

    public static Screen traits() {
        List<Text> pages = new ArrayList<>();
        passivePages(pages, "TRAITS", Trait.values(), ClientRpg.data.traitId);
        return make(pages, 0);
    }

    public static Screen perks() {
        List<Text> pages = new ArrayList<>();
        passivePages(pages, "PERKS", Perk.values(), ClientRpg.data.perkId);
        return make(pages, 0);
    }

    private static Screen make(List<Text> pages, int startPage) {
        List<RawFilteredPair<Text>> raw = new ArrayList<>();
        for (Text pg : pages) raw.add(RawFilteredPair.of(pg));
        ItemStack stack = new ItemStack(Items.WRITTEN_BOOK);
        stack.set(DataComponentTypes.WRITTEN_BOOK_CONTENT,
                new WrittenBookContentComponent(RawFilteredPair.of("RealmForge"), "RealmForge", 0, raw, true));
        return new RpgBookScreen(BookScreen.Contents.create(stack), startPage);
    }

    private static String playerName() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player != null ? mc.player.getName().getString() : "Player";
    }

    // ------------------------------------------------------------------ Page 1 - Player
    private static Text playerPage(RpgData d, String name) {
        Rank r = d.rank();
        Trait tr = d.trait(); Perk pk = d.perk();
        MutableText m = Text.empty();
        m.append(t("PLAYER\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        m.append(t("[" + r.icon + "] " + name + "\n", Formatting.BOLD, Formatting.BLACK));
        m.append(t("Rank: ", Formatting.DARK_GRAY)).append(t(r.label + "\n", Formatting.BOLD, r.bookColor));
        m.append(t("Level: ", Formatting.DARK_GRAY)).append(t(d.level + "\n", Formatting.BLACK));
        m.append(t("EXP: ", Formatting.DARK_GRAY)).append(t(d.level >= RpgData.MAX_LEVEL ? "MAX\n" : d.exp + " / " + d.expRequired() + "\n", Formatting.BLACK));
        Rank nx = r.next();
        if (nx != null) m.append(t("Next: " + nx.label + " (Lv" + nx.minLevel + ", " + nx.minKills + " kills; you: " + d.kills + ")\n", Formatting.GRAY));
        m.append(t("\nTrait: ", Formatting.DARK_GRAY));
        if (tr != null) m.append(t(tr.displayName(), tr.rarity().bookColor, Formatting.BOLD)).append(t(" (" + tr.rarity().label + ")\n", tr.rarity().bookColor));
        m.append(t("Perk: ", Formatting.DARK_GRAY));
        if (pk != null) m.append(t(pk.displayName(), pk.rarity().bookColor, Formatting.BOLD)).append(t(" (" + pk.rarity().label + ")\n", pk.rarity().bookColor));
        m.append(t("\nStat points: ", Formatting.DARK_GRAY)).append(t(String.valueOf(d.points), d.points > 0 ? Formatting.DARK_GREEN : Formatting.BLACK, Formatting.BOLD));
        return m;
    }

    // ------------------------------------------------------------------ Page 2 - Attributes (bars + buttons)
    private static Text attributesPage(RpgData d) {
        int cap = Math.max(10, RpgData.STARTING_POINTS + RpgData.POINTS_PER_LEVEL * (d.level - 1));
        MutableText m = Text.empty();
        m.append(t("ATTRIBUTES\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        for (Stat s : Stat.values()) {
            int v = d.stat(s), bonus = d.bonusOf(s);
            m.append(t(s.abbr + " " + v + " ", Formatting.BOLD, s.bookColor));
            if (d.points >= 1) m.append(button("[+1]", "/realmforge ui upgrade " + s.id() + " 1", s.bookColor, "Spend 1 point on " + s.label));
            else m.append(t("[+1]", Formatting.GRAY));
            m.append(Text.literal(" "));
            if (d.points >= 5) m.append(button("[+5]", "/realmforge ui upgrade " + s.id() + " 5", s.bookColor, "Spend 5 points on " + s.label));
            else m.append(t("[+5]", Formatting.GRAY));
            m.append(Text.literal("\n"));

            int filled = Math.round(Math.min(1f, v / (float) cap) * BAR_LEN);
            m.append(t("|".repeat(filled), s.bookColor));
            m.append(t("|".repeat(BAR_LEN - filled), Formatting.GRAY));
            if (bonus != 0) m.append(t(" " + (bonus > 0 ? "+" : "") + bonus, bonus > 0 ? Formatting.DARK_GREEN : Formatting.DARK_RED));
            m.append(Text.literal("\n"));
        }
        m.append(t("Points left: ", Formatting.DARK_GRAY)).append(t(String.valueOf(d.points), d.points > 0 ? Formatting.DARK_GREEN : Formatting.BLACK, Formatting.BOLD));
        return m;
    }

    // ------------------------------------------------------------------ Page 3 - Stat effects (all five, compact)
    private static Text effectsPage(RpgData d) {
        MutableText m = Text.empty();
        m.append(t("STAT EFFECTS\n", Formatting.BOLD, Formatting.DARK_PURPLE));

        head(m, Stat.STR, d);
        body(m, Stat.STR, "+" + pct(d.physMult() - 1) + " phys/melee dmg");

        head(m, Stat.AGI, d);
        body(m, Stat.AGI, "+" + pct(d.speedBonus()) + " move speed");
        body(m, Stat.AGI, pct(d.dodge()) + " dodge chance");

        head(m, Stat.VIT, d);
        body(m, Stat.VIT, "+" + d.maxHealthBonus() + " HP (" + (20 + d.maxHealthBonus()) + " max)");

        head(m, Stat.INT, d);
        body(m, Stat.INT, "+" + pct(d.intSkillMult() - 1) + " skill/magic dmg");

        head(m, Stat.ENE, d);
        body(m, Stat.ENE, (int) d.maxEnergy() + " max energy");
        body(m, Stat.ENE, "+" + String.format(Locale.ROOT, "%.1f", d.regenPerSecond()) + " energy/sec");
        return m;
    }

    private static void head(MutableText m, Stat s, RpgData d) {
        m.append(t(s.abbr + " " + d.stat(s) + "\n", Formatting.BOLD, s.bookColor));
    }
    private static void body(MutableText m, Stat s, String text) {
        m.append(t(text + "\n", s.bookColor));
    }

    // ------------------------------------------------------------------ Page 4 - References hub
    private static Text referencesPage(RpgData d) {
        Trait tr = d.trait(); Perk pk = d.perk();
        MutableText m = Text.empty();
        m.append(t("REFERENCES\n\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        m.append(link("[ TRAIT ]", "rf:traits", Formatting.DARK_AQUA, "Open the trait list")).append(Text.literal("   "));
        m.append(link("[ PERK ]", "rf:perks", Formatting.DARK_AQUA, "Open the perk list")).append(Text.literal("\n\n"));
        m.append(t("Your trait:\n", Formatting.DARK_GRAY));
        if (tr != null) m.append(t(tr.displayName() + " (" + tr.rarity().label + ")\n\n", tr.rarity().bookColor, Formatting.BOLD));
        m.append(t("Your perk:\n", Formatting.DARK_GRAY));
        if (pk != null) m.append(t(pk.displayName() + " (" + pk.rarity().label + ")\n\n", pk.rarity().bookColor, Formatting.BOLD));
        m.append(t("Both are permanent.", Formatting.GRAY));
        return m;
    }

    // ------------------------------------------------------------------ Trait / Perk lists
    private static void passivePages(List<Text> pages, String title, Passive[] all, String selectedId) {
        int count = (int) Math.ceil(all.length / (double) PER_PAGE);
        for (int pg = 0; pg < count; pg++) {
            MutableText m = Text.empty();
            m.append(link("[Back]", "rf:main", Formatting.DARK_AQUA, "Back to references"));
            m.append(t(" " + title + " " + (pg + 1) + "/" + count + "\n", Formatting.BOLD, Formatting.DARK_PURPLE));
            for (int i = pg * PER_PAGE; i < Math.min(all.length, (pg + 1) * PER_PAGE); i++) {
                Passive p = all[i];
                boolean mine = p.id().equalsIgnoreCase(selectedId);
                MutableText head = t((mine ? "\u2605 " : "") + p.displayName() + " (" + p.rarity().label + ")",
                        p.rarity().bookColor, Formatting.BOLD);
                if (mine) head.formatted(Formatting.UNDERLINE);
                m.append(head).append(Text.literal("\n"));
                m.append(t(p.description() + "\n", Formatting.GRAY));
                List<String> buffs = p.effects().buffs(), debuffs = p.effects().debuffs();
                if (!buffs.isEmpty()) m.append(t(String.join(", ", buffs) + "\n", Formatting.DARK_GREEN));
                if (!debuffs.isEmpty()) m.append(t(String.join(", ", debuffs) + "\n", Formatting.DARK_RED));
                if (mine) m.append(t("<< YOURS (permanent)\n", Formatting.GOLD, Formatting.BOLD));
                m.append(Text.literal("\n"));
            }
            pages.add(m);
        }
    }

    // ------------------------------------------------------------------ helpers
    private static String pct(double v) {
        double p = v * 100;
        return (Math.abs(p - Math.round(p)) < 0.05 ? String.valueOf(Math.round(p)) : String.format(Locale.ROOT, "%.1f", p)) + "%";
    }

    private static MutableText t(String s, Formatting... f) { return Text.literal(s).formatted(f); }

    private static MutableText button(String label, String command, Formatting color, String hover) {
        return Text.literal(label).setStyle(Style.EMPTY.withColor(color).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, command))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal(hover))));
    }

    /** Intercepted by RpgBookScreen (value starts with "rf:"). */
    private static MutableText link(String label, String value, Formatting color, String hover) {
        return Text.literal(label).setStyle(Style.EMPTY.withColor(color).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.CHANGE_PAGE, value))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal(hover))));
    }
}
