package com.realmforge.data;

import java.util.Locale;

public enum Skill {
    POWER_STRIKE("Power Strike", "Heavy blow to the foe in front of you. Scales with STR.", 1, 15, 120, Stat.STR),
    DASH("Dash", "Burst of speed in your facing direction. Scales with AGI.", 3, 10, 80, Stat.AGI),
    ARCANE_BOLT("Arcane Bolt", "Hitscan magic bolt, range 24. Scales with INT.", 5, 20, 100, Stat.INT),
    MEND("Mend", "Restore your health. Scales with ENE.", 8, 25, 300, Stat.ENE);

    public static final int SLOTS = 4;
    public final String label, desc;
    public final int unlockLevel, energyCost, cooldownTicks;
    public final Stat stat;

    Skill(String label, String desc, int unlockLevel, int energyCost, int cooldownTicks, Stat stat) {
        this.label = label; this.desc = desc; this.unlockLevel = unlockLevel;
        this.energyCost = energyCost; this.cooldownTicks = cooldownTicks; this.stat = stat;
    }

    public String id() { return name().toLowerCase(Locale.ROOT); }
    public static Skill byId(String id) {
        if (id == null) return null;
        for (Skill s : values()) if (s.id().equalsIgnoreCase(id)) return s;
        return null;
    }
}
