package com.realmforge.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.BookScreen;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Style;
import net.minecraft.util.Identifier;

/**
 * Vanilla BookScreen drawn at 200%, centered on screen, with no background blur.
 * Links whose value starts with "rf:" switch between the main book and the trait/perk books, so the
 * trait/perk pages can only be reached through the TRAIT / PERK buttons (arrows never lead into them).
 */
public class RpgBookScreen extends BookScreen {
    public static final float TARGET_SCALE = 2.0f;
    private static final Identifier BOOK_TEXTURE = Identifier.ofVanilla("textures/gui/book.png");

    private final int startPage;
    private float scale = 1f;

    public RpgBookScreen(BookScreen.Contents contents, int startPage) {
        super(contents);
        this.startPage = startPage;
    }

    @Override
    protected void init() {
        super.init();
        if (startPage > 0) this.setPage(startPage);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        float cx = this.width / 2f;
        float cy = this.height / 2f;
        ctx.getMatrices().push();
        ctx.getMatrices().translate(cx, cy, 0f);
        ctx.getMatrices().scale(scale, scale, 1f);
        ctx.getMatrices().translate(-cx, -cy, 0f);
        super.render(ctx, (int) (cx + (mouseX - cx) / scale),
                (int) (cy + (mouseY - cy) / scale), delta);
        ctx.getMatrices().pop();
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderInGameBackground(ctx);                      // plain dim, no blur
        int x = (this.width - 192) / 2;
        int y = (this.height - 192) / 2;
        ctx.drawTexture(BOOK_TEXTURE, x, y, 0, 0, 192, 192);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        double cx = this.width / 2.0;
        double cy = this.height / 2.0;
        return super.mouseClicked(cx + (mouseX - cx) / scale,
                cy + (mouseY - cy) / scale, button);
    }

    @Override
    public boolean handleTextClick(Style style) {
        ClickEvent ev = style == null ? null : style.getClickEvent();
        if (ev != null && ev.getAction() == ClickEvent.Action.CHANGE_PAGE && ev.getValue().startsWith("rf:")) {
            if (this.client != null) {
                switch (ev.getValue()) {
                    case "rf:traits" -> this.client.setScreen(RpgBook.traits());
                    case "rf:perks" -> this.client.setScreen(RpgBook.perks());
                    default -> this.client.setScreen(RpgBook.main(3)); // back to References
                }
            }
            return true;
        }
        return super.handleTextClick(style);
    }
}
