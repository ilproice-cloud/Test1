package com.realmforge.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.BookScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.util.Identifier;

/** Unified RealmForge book. All book pages stay inside the same vanilla page-turning screen. */
public class RpgBookScreen extends BookScreen {
    private static final Identifier BOOK_TEXTURE = Identifier.ofVanilla("textures/gui/book.png");
    private static final float BOOK_SCALE = 3.25f;
    private final int startPage;

    public RpgBookScreen(BookScreen.Contents contents, int startPage) {
        super(contents);
        this.startPage = startPage;
    }

    @Override
    protected void init() {
        super.init();
        // Remove only the vanilla Done/exit button; preserve page-turn controls.
        this.children().removeIf(element -> element instanceof ButtonWidget button
                && button.getMessage().getString().equalsIgnoreCase("Done"));
        if (startPage > 0) this.setPage(startPage);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.getMatrices().push();
        ctx.getMatrices().translate(this.width / 2.0, this.height / 2.0, 0);
        ctx.getMatrices().scale(BOOK_SCALE, BOOK_SCALE, 1.0f);
        ctx.getMatrices().translate(-this.width / 2.0, -this.height / 2.0, 0);
        super.render(ctx, unscaleX(mouseX), unscaleY(mouseY), delta);
        ctx.getMatrices().pop();
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Keep Minecraft's darkened world background but do not add a blur shader.
        this.renderInGameBackground(ctx);
        int x = (this.width - 192) / 2;
        ctx.drawTexture(BOOK_TEXTURE, x, 2, 0, 0, 192, 192);
    }

    private double unscaleX(double x) { return (x - this.width / 2.0) / BOOK_SCALE + this.width / 2.0; }
    private double unscaleY(double y) { return (y - this.height / 2.0) / BOOK_SCALE + this.height / 2.0; }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return super.mouseClicked(unscaleX(mouseX), unscaleY(mouseY), button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        return super.mouseReleased(unscaleX(mouseX), unscaleY(mouseY), button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return super.mouseDragged(unscaleX(mouseX), unscaleY(mouseY), button,
                deltaX / BOOK_SCALE, deltaY / BOOK_SCALE);
    }

    @Override
    public void mouseMoved(double mouseX, double mouseY) {
        super.mouseMoved(unscaleX(mouseX), unscaleY(mouseY));
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return super.mouseScrolled(unscaleX(mouseX), unscaleY(mouseY), horizontalAmount, verticalAmount);
    }
}
