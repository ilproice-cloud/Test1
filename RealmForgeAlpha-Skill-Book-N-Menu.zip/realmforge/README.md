# RealmForge Fabric 1.21.1

The main RPG book is intentionally exactly six pages: Player, Attributes, Stat Effects, References, Stats in Bars, and Information. The Information page opens the Traits and Perks catalogues through clickable buttons; catalogue entries are in separate book screens and are not appended to the main book.

New players start with 5/5 energy. Energy remains capped at 5 unless the configured base/stat formula is changed in `RpgData.java`.

Build with Java 21 and Gradle 8.8: `gradle clean build --no-daemon`.
