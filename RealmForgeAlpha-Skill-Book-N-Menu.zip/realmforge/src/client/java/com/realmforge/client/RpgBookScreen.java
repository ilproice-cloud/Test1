package com.realmforge.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Formatting;
import com.realmforge.data.Stat;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Custom responsive two-page RealmForge book; deliberately does not use vanilla BookScreen. */
public final class RpgBookScreen extends Screen {
    private static final Identifier BOOK_TEXTURE = Identifier.of("realmforge", "textures/gui/rpg_book_background.png");
    private static final int ART_W = 463, ART_H = 301;
    private final List<Text> pages;
    private int firstPage;
    private int bookX, bookY, bookW, bookH;
    private float scale;
    private int closeButtonX, closeButtonY, closeButtonW, closeButtonH;
    private int leftButtonX, rightButtonX, navButtonY, navButtonW, navButtonH;
    private final boolean catalogueScreen;

    public RpgBookScreen(List<Text> pages, int startPage, boolean catalogueScreen) {
        super(Text.literal("RealmForge"));
        this.pages = new ArrayList<>(pages);
        this.firstPage = clampFirstPage(startPage);
        this.catalogueScreen = catalogueScreen;
    }

    @Override protected void init() {
        this.clearChildren();
        float sx = (this.width - 116.0f) / ART_W;
        float sy = (this.height - 36.0f) / ART_H;
        scale = Math.max(0.25f, Math.min(1.65f, Math.min(sx, sy)));
        bookW = Math.max(1, Math.round(ART_W * scale));
        bookH = Math.max(1, Math.round(ART_H * scale));
        bookX = (this.width - bookW) / 2;
        bookY = Math.max(4, (this.height - bookH) / 2);

        // The supplied parchment X is drawn over this real clickable widget.
        int buttonW = Math.max(22, Math.round(30 * scale));
        int buttonH = Math.max(22, Math.round(30 * scale));
        int closeX = Math.min(this.width - buttonW - 2, bookX + bookW - buttonW / 2);
        int closeY = Math.max(2, bookY - buttonH / 2);
        addDrawableChild(ButtonWidget.builder(Text.empty(), b -> close())
                .dimensions(closeX, closeY, buttonW, buttonH).build());
        closeButtonX = closeX; closeButtonY = closeY; closeButtonW = buttonW; closeButtonH = buttonH;

        // Icon-only arrow widgets. Their hitboxes remain clickable on touch screens.
        int sideGap = Math.max(4, Math.round(10 * scale));
        int leftX = Math.max(2, bookX - buttonW - sideGap);
        int rightX = Math.min(this.width - buttonW - 2, bookX + bookW + sideGap);
        if (leftX + buttonW > bookX) leftX = Math.max(2, bookX + sideGap);
        if (rightX < bookX + bookW) rightX = Math.min(this.width - buttonW - 2, bookX + bookW - buttonW - sideGap);
        int buttonY = Math.max(2, Math.min(this.height - buttonH - 2, bookY + bookH / 2 - buttonH / 2));
        leftButtonX = leftX; rightButtonX = rightX; navButtonY = buttonY; navButtonW = buttonW; navButtonH = buttonH;
        addDrawableChild(ButtonWidget.builder(Text.empty(), b -> changeSpread(-2))
                .dimensions(leftX, buttonY, buttonW, buttonH).build());
        addDrawableChild(ButtonWidget.builder(Text.empty(), b -> changeSpread(2))
                .dimensions(rightX, buttonY, buttonW, buttonH).build());
    }

    private void changeSpread(int amount) {
        int next = clampFirstPage(firstPage + amount);
        if (next != firstPage) {
            MinecraftClient.getInstance().setScreen(new RpgBookScreen(pages, next, catalogueScreen));
        }
    }

    private void sendCommand(String command) {
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        if (mc.player != null && mc.player.networkHandler != null) {
            mc.player.networkHandler.sendChatCommand(command);
        }
    }

    private int clampFirstPage(int requested) {
        // Keep the first page on an even index so the book always shows a left/right pair.
        int maxFirst = Math.max(0, ((pages.size() - 1) / 2) * 2);
        return Math.max(0, Math.min(requested, maxFirst));
    }

    private void refreshPageButtons() {
        firstPage = clampFirstPage(firstPage);
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // No blur and no dark overlay: leave the world crisp behind the custom book.
        // IMPORTANT: draw the texture at its real pixel size, then scale the matrix.
        // Passing bookW/bookH as the source-region size makes Minecraft tile the texture,
        // which caused duplicate books along the right and bottom edges.
        ctx.getMatrices().push();
        ctx.getMatrices().translate(bookX, bookY, 0);
        ctx.getMatrices().scale(scale, scale, 1.0f);
        ctx.drawTexture(BOOK_TEXTURE, 0, 0, 0, 0, ART_W, ART_H, ART_W, ART_H);
        // Text uses the same coordinate system as the artwork, so it stays on the paper.
        drawPage(ctx, firstPage, 30, 38, 185, 10);
        drawPage(ctx, firstPage + 1, 258, 38, 185, 10);
        ctx.getMatrices().pop();
        super.render(ctx, mouseX, mouseY, delta);
        // The supplied icons are the visible faces of real clickable widgets.
        ctx.drawTexture(Identifier.of("realmforge", "textures/gui/previous_button.png"),
                leftButtonX, navButtonY, 0, 0, navButtonW, navButtonH, navButtonW, navButtonH);
        ctx.drawTexture(Identifier.of("realmforge", "textures/gui/next_button.png"),
                rightButtonX, navButtonY, 0, 0, navButtonW, navButtonH, navButtonW, navButtonH);
        ctx.drawTexture(Identifier.of("realmforge", "textures/gui/exit_button.png"),
                closeButtonX, closeButtonY, 0, 0, closeButtonW, closeButtonH, closeButtonW, closeButtonH);
    }

    private void drawPage(DrawContext ctx, int index, int x, int y, int maxWidth, int lineHeight) {
        if (index < 0 || index >= pages.size()) return;
        // The entire book and its text share the same responsive scale. This keeps glyphs
        // sharp and much larger than the previous double-scaled text on mobile screens.
        List<OrderedText> lines = textRenderer.wrapLines(pages.get(index), maxWidth);
        int maxLines = 17;
        int drawn = 0;
        // Slightly reduce text size without changing the book art or its responsive scale.
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x, y, 0);
        ctx.getMatrices().scale(0.92f, 0.92f, 1.0f);
        for (OrderedText line : lines) {
            if (drawn >= maxLines) break;
            ctx.drawText(textRenderer, line, 0, drawn * lineHeight, 0xFF292018, false);
            drawn++;
        }
        // Page number sits higher, inside the lower margin of each paper page.
        ctx.drawText(textRenderer, Text.literal(String.valueOf(index + 1)).formatted(Formatting.DARK_GRAY),
                maxWidth / 2 - 2, 238, 0xFF6B6256, false);
        ctx.getMatrices().pop();
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // Intentionally empty: do not invoke Minecraft's blurred menu background.
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        // Make the actual printed text clickable, like the links in vanilla Book & Quill.
        double lx = (mouseX - bookX) / scale;
        double ly = (mouseY - bookY) / scale;
        if (catalogueScreen) {
            if (hitText(lx, ly, 30, 38, 0, 1, "[ BACK TO INFORMATION ]")) {
                MinecraftClient.getInstance().setScreen(RpgBook.main(4)); return true;
            }
            if (hitText(lx, ly, 258, 38, 0, 1, "[ BACK TO INFORMATION ]")) {
                MinecraftClient.getInstance().setScreen(RpgBook.main(4)); return true;
            }
        } else if (firstPage == 0) {
            Stat[] stats = Stat.values();
            for (int i = 0; i < stats.length; i++) {
                Stat stat = stats[i];
                String label = stat.abbr + " " + ClientRpg.data.stat(stat) + " ";
                int labelWidth = textRenderer.getWidth(label);
                int row = 1 + i * 2;
                if (hitTextRange(lx, ly, 258, 38, labelWidth, row, textRenderer.getWidth("[+1]"))) {
                    sendCommand("realmforge ui upgrade " + stat.name().toLowerCase(java.util.Locale.ROOT) + " 1");
                    return true;
                }
                int x5 = labelWidth + textRenderer.getWidth("[+1] ");
                if (hitTextRange(lx, ly, 258, 38, x5, row, textRenderer.getWidth("[+5]"))) {
                    sendCommand("realmforge ui upgrade " + stat.name().toLowerCase(java.util.Locale.ROOT) + " 5");
                    return true;
                }
            }
        } else if (!catalogueScreen && firstPage == 4) {
            if (hitText(lx, ly, 258, 38, 0, 3, "[ TRAITS ]")) {
                MinecraftClient.getInstance().setScreen(RpgBook.screen(-2)); return true;
            }
            if (hitText(lx, ly, 258, 38, 0, 7, "[ PERKS ]")) {
                MinecraftClient.getInstance().setScreen(RpgBook.screen(-3)); return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private boolean hitText(double lx, double ly, int pageX, int pageY, int textX, int line, String text) {
        return hitTextRange(lx, ly, pageX, pageY, textX, line, textRenderer.getWidth(text));
    }

    private boolean hitTextRange(double lx, double ly, int pageX, int pageY, int textX, int line, int textWidth) {
        double x = pageX + textX * 0.92;
        double y = pageY + line * 10 * 0.92;
        return lx >= x - 3 && lx <= x + textWidth * 0.92 + 3
                && ly >= y - 3 && ly <= y + 10 * 0.92 + 3;
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (keyCode == GLFW.GLFW_KEY_LEFT) { changeSpread(-2); return true; }
        if (keyCode == GLFW.GLFW_KEY_RIGHT) { changeSpread(2); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean shouldPause() { return false; }
}
