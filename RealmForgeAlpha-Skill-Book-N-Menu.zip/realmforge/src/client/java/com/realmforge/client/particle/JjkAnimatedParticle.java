package com.realmforge.client.particle;

import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.SimpleParticleType;


/** Animated billboard using the original ProjectJJK particle frame sequences. */
public final class JjkAnimatedParticle extends SpriteBillboardParticle {
    private final SpriteProvider sprites;

    private JjkAnimatedParticle(ClientWorld world, double x, double y, double z,
                                double vx, double vy, double vz, SpriteProvider sprites) {
        super(world, x, y, z, vx, vy, vz);
        this.sprites = sprites;
        this.maxAge = 8;
        this.scale = 0.42f;
        this.velocityMultiplier = 0.82f;
        this.setSprite(sprites.getSprite(0, this.maxAge));
    }

    @Override
    public ParticleTextureSheet getType() {
        return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.dead) this.setSprite(this.sprites.getSprite(this.age, this.maxAge));
    }

    public static final class Factory implements ParticleFactory<SimpleParticleType> {
        private final SpriteProvider sprites;
        public Factory(SpriteProvider sprites) { this.sprites = sprites; }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientWorld world,
                                       double x, double y, double z,
                                       double vx, double vy, double vz) {
            return new JjkAnimatedParticle(world, x, y, z, vx, vy, vz, sprites);
        }
    }
}
