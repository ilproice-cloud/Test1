package com.realmforge.client;

import com.realmforge.data.Skill;
import com.realmforge.data.Stat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

/** Three-page skill book for assigning skills to Z/X/C. */
public final class SkillBookScreen extends Screen {
    private static final Identifier BOOK = Identifier.of("realmforge", "textures/gui/rpg_book_background.png");
    private static final Identifier[] ICONS = {
        Identifier.of("realmforge", "textures/gui/strong_punch.png"),
        Identifier.of("realmforge", "textures/gui/uppercut.png"),
        Identifier.of("realmforge", "textures/gui/barrage.png")
    };
    private static final Skill[] SKILLS = { Skill.STRONG_PUNCH, Skill.UPPERCUT, Skill.BARRAGE };
    private int page;
    private int bx, by, bw, bh;
    private float scale;
    private int prevX, nextX, btnY, btnW, btnH, closeX, closeY;

    public SkillBookScreen(int page) { super(Text.literal("Skill Book")); this.page = Math.max(0, Math.min(2, page)); }

    @Override protected void init() {
        clearChildren();
        scale = Math.max(0.25f, Math.min(1.65f, Math.min((width - 90f) / 463f, (height - 28f) / 301f)));
        bw = Math.round(463 * scale); bh = Math.round(301 * scale); bx = (width-bw)/2; by = Math.max(4,(height-bh)/2);
        btnW = Math.max(22, Math.round(30*scale)); btnH=btnW; btnY=Math.max(2,Math.min(height-btnH-2,by+bh/2-btnH/2));
        prevX=Math.max(2,bx-btnW-8); nextX=Math.min(width-btnW-2,bx+bw+8); closeX=Math.min(width-btnW-2,bx+bw-btnW/2); closeY=Math.max(2,by-btnH/2);
        addDrawableChild(ButtonWidget.builder(Text.empty(), b -> setPage(page-1)).dimensions(prevX,btnY,btnW,btnH).build());
        addDrawableChild(ButtonWidget.builder(Text.empty(), b -> setPage(page+1)).dimensions(nextX,btnY,btnW,btnH).build());
        addDrawableChild(ButtonWidget.builder(Text.empty(), b -> close()).dimensions(closeX,closeY,btnW,btnH).build());
        int y = by + Math.round(250*scale); int gap=Math.max(4,Math.round(7*scale)); int w=Math.max(48,Math.round(52*scale));
        int start=width/2-(3*w+2*gap)/2;
        for(int i=0;i<3;i++){ final int slot=i; String existing=ClientRpg.data==null?"":ClientRpg.data.slots[i];
            Text keyText=Text.literal(new String[]{"Z","X","C"}[i]).formatted(SKILLS[page].id().equalsIgnoreCase(existing)?Formatting.GREEN:Formatting.RED);
            addDrawableChild(ButtonWidget.builder(keyText, b -> bind(slot)).dimensions(start+i*(w+gap),y,w,Math.max(20,Math.round(22*scale))).build()); }
    }
    private void setPage(int p){ if(p>=0&&p<3) MinecraftClient.getInstance().setScreen(new SkillBookScreen(p)); }
    private void bind(int slot){ var mc=MinecraftClient.getInstance(); if(mc.player!=null) mc.player.networkHandler.sendChatCommand("realmforge skill bind "+(slot+1)+" "+SKILLS[page].id()); }

    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta){
        ctx.getMatrices().push(); ctx.getMatrices().translate(bx,by,0); ctx.getMatrices().scale(scale,scale,1);
        ctx.drawTexture(BOOK,0,0,0,0,463,301,463,301);
        Skill s=SKILLS[page];
        ctx.drawCenteredTextWithShadow(textRenderer,Text.literal("SKILL BOOK").formatted(Formatting.DARK_PURPLE),231,18,0xFFFFFFFF);
        ctx.drawTexture(ICONS[page],78,55,0,0,90,90,90,90);
        ctx.drawText(textRenderer,Text.literal(s.label).formatted(Formatting.DARK_PURPLE,Formatting.BOLD),183,52,0xFF292018,false);
        ctx.drawText(textRenderer,Text.literal("Rarity: Rare").formatted(Formatting.BLUE),183,69,0xFF292018,false);
        int str=ClientRpg.data==null?0:ClientRpg.data.stat(Stat.STR);
        double base=page==0?1.5:page==1?0.5:0.25;
        double hit=(base+0.6*str)*(ClientRpg.data==null?1:ClientRpg.data.physMult())*(ClientRpg.data==null?1:ClientRpg.data.skillBonus());
        ctx.drawText(textRenderer,Text.literal(String.format(java.util.Locale.ROOT,"Damage: %.1f  |  STR max: %.1f",base,hit)),183,88,0xFF292018,false);
        String desc=page==0?"A crushing punch with a chance to trigger Black Flash.":page==1?"An explosive rising strike that launches both fighters.":"A relentless flurry that holds the target in place; each hit refreshes your aerial time.";
        int line=0; for(var t:textRenderer.wrapLines(Text.literal(desc),180)){ if(line>5)break; ctx.drawText(textRenderer,t,183,108+line*12,0xFF292018,false); line++; }
        ctx.drawCenteredTextWithShadow(textRenderer,Text.literal("Choose a key to equip this skill").formatted(Formatting.DARK_GRAY),231,226,0xFFFFFFFF);
        for(int i=0;i<3;i++){String slot=ClientRpg.data==null?"":ClientRpg.data.slots[i]; boolean equipped=SKILLS[page].id().equalsIgnoreCase(slot); ctx.drawCenteredTextWithShadow(textRenderer,Text.literal(equipped?"EQUIPPED":"ASSIGN").formatted(equipped?Formatting.GREEN:Formatting.GRAY),231-((3*52+14)/2)+i*59+26,250,0xFFFFFFFF);}
        ctx.getMatrices().pop(); super.render(ctx,mouseX,mouseY,delta);
        ctx.drawTexture(Identifier.of("realmforge","textures/gui/previous_button.png"),prevX,btnY,0,0,btnW,btnH,btnW,btnH);
        ctx.drawTexture(Identifier.of("realmforge","textures/gui/next_button.png"),nextX,btnY,0,0,btnW,btnH,btnW,btnH);
        ctx.drawTexture(Identifier.of("realmforge","textures/gui/exit_button.png"),closeX,closeY,0,0,btnW,btnH,btnW,btnH);
    }
    @Override public boolean keyPressed(int key,int scan,int mods){if(key==GLFW.GLFW_KEY_ESCAPE||key==GLFW.GLFW_KEY_N){close();return true;} if(key==GLFW.GLFW_KEY_LEFT){setPage(page-1);return true;} if(key==GLFW.GLFW_KEY_RIGHT){setPage(page+1);return true;} return super.keyPressed(key,scan,mods);}
    @Override public void renderBackground(DrawContext c,int x,int y,float d){}
    @Override public boolean shouldPause(){return false;}
}
