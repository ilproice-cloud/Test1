package com.realmforge.net;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server -> client. snbt = full RpgData (+ equipment + cooldowns). openPage >= 0 opens the book at that page. */
public record SyncPayload(String snbt, int openPage) implements CustomPayload {
    public static final Id<SyncPayload> ID = new Id<>(Identifier.of("realmforge", "sync"));
    public static final PacketCodec<ByteBuf, SyncPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.STRING, SyncPayload::snbt,
            PacketCodecs.INTEGER, SyncPayload::openPage,
            SyncPayload::new);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}
