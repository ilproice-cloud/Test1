package com.realmforge.data;

import java.util.Locale;
import static com.realmforge.data.Stat.*;

public enum Perk implements Passive {
    THICK_SKIN("Thick Skin", Rarity.COMMON, "Shrugs off minor hits.", Effects.of().dmgIn(-0.03).regen(-0.05)),
    SECOND_WIND("Second Wind", Rarity.COMMON, "Recovers fast, tires fast.", Effects.of().regen(0.15).energy(-0.05)),
    KEEN_EYE("Keen Eye", Rarity.UNCOMMON, "Sees every opening.", Effects.of().dmgOut(0.04).dodge(-0.02)),
    SCHOLARS_FOCUS("Scholar's Focus", Rarity.UNCOMMON, "Skills hit harder.", Effects.of().skillDmg(0.08).dmgIn(0.02)),
    VAMPIRIC_TOUCH("Vampiric Touch", Rarity.RARE, "Drinks a little life.", Effects.of().lifesteal(0.03).hp(-2)),
    ENERGIZED("Energized", Rarity.RARE, "Big tank, gentle hands.", Effects.of().energy(0.20).regen(0.10).dmgOut(-0.03)),
    SPELLBLADE("Spellblade", Rarity.EPIC, "Steel meets sorcery.", Effects.of().skillDmg(0.15).stat(STR, -1)),
    JUGGERNAUT("Juggernaut", Rarity.EPIC, "Slow and unstoppable.", Effects.of().hp(8).dmgIn(-0.08).stat(AGI, -2)),
    PHOENIX_HEART("Phoenix Heart", Rarity.LEGENDARY, "Burns bright, drains fast.", Effects.of().hp(10).lifesteal(0.04).stat(ENE, -2)),
    TITANS_MIGHT("Titan's Might", Rarity.LEGENDARY, "Raw crushing force.", Effects.of().dmgOut(0.10).stat(STR, 3).regen(-0.10)),
    WORLD_EATER("World Eater", Rarity.MYTHICAL, "Devours everything.", Effects.of().dmgOut(0.20).skillDmg(0.20).exp(0.15).dmgIn(0.15));

    private final String display, desc; private final Rarity rarity; private final Effects fx;
    Perk(String display, Rarity r, String desc, Effects fx) { this.display = display; this.rarity = r; this.desc = desc; this.fx = fx; }

    @Override public String id() { return name().toLowerCase(Locale.ROOT); }
    @Override public String displayName() { return display; }
    @Override public Rarity rarity() { return rarity; }
    @Override public String description() { return desc; }
    @Override public Effects effects() { return fx; }

    public static Perk byId(String id) {
        if (id == null) return null;
        for (Perk p : values()) if (p.id().equalsIgnoreCase(id)) return p;
        return null;
    }
}
