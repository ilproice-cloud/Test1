package com.realmforge.data;

import net.minecraft.util.Formatting;
import java.util.Locale;

public enum Stat {
    STR("STR", "Strength", Formatting.RED, Formatting.DARK_RED),
    AGI("AGI", "Agility", Formatting.AQUA, Formatting.DARK_AQUA),
    VIT("VIT", "Vitality", Formatting.GREEN, Formatting.DARK_GREEN),
    INT("INT", "Intelligence", Formatting.BLUE, Formatting.DARK_BLUE),
    ENE("ENE", "Energy", Formatting.YELLOW, Formatting.GOLD);

    public final String abbr, label;
    /** Colour on dark backgrounds / colour on the book's light page. */
    public final Formatting color, bookColor;

    Stat(String abbr, String label, Formatting color, Formatting bookColor) {
        this.abbr = abbr; this.label = label; this.color = color; this.bookColor = bookColor;
    }
    public String id() { return name().toLowerCase(Locale.ROOT); }
    public static Stat byId(String s) {
        for (Stat st : values()) if (st.id().equalsIgnoreCase(s)) return st;
        return null;
    }
}
