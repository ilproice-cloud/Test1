package com.realmforge.data;

import java.util.Locale;

/** Temporary melee moves adapted for RealmForge from the supplied Project JJK reference mod. */
public enum Skill {
    STRONG_PUNCH("Strong Punch", "A heavy close-range punch with a chance for Black Flash.", 1, 0, 100, Stat.STR),
    UPPERCUT("Uppercut", "Launches the target upward and briefly immobilizes them.", 1, 0, 200, Stat.STR),
    BARRAGE("Barrage", "Unleashes a rapid flurry of 15 punches against a nearby target.", 1, 0, 300, Stat.STR);

    public static final int SLOTS = 3;
    public final String label, desc;
    public final int unlockLevel, energyCost, cooldownTicks;
    public final Stat stat;

    Skill(String label, String desc, int unlockLevel, int energyCost, int cooldownTicks, Stat stat) {
        this.label = label;
        this.desc = desc;
        this.unlockLevel = unlockLevel;
        this.energyCost = energyCost;
        this.cooldownTicks = cooldownTicks;
        this.stat = stat;
    }

    public String id() { return name().toLowerCase(Locale.ROOT); }

    public static Skill byId(String id) {
        if (id == null) return null;
        for (Skill s : values()) if (s.id().equalsIgnoreCase(id)) return s;
        // Migrate saved slots from the previous temporary skill set.
        return switch (id.toLowerCase(Locale.ROOT)) {
            case "power_strike" -> STRONG_PUNCH;
            case "dash" -> UPPERCUT;
            case "arcane_bolt", "mend" -> BARRAGE;
            default -> null;
        };
    }
}
