package com.realmforge;

import com.realmforge.data.*;
import com.realmforge.logic.EquipmentBonuses;
import com.realmforge.logic.StatApplier;
import com.realmforge.net.SyncPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public final class RpgManager {
    private RpgManager() { }

    public static RpgState state(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(RpgState.TYPE, "realmforge");
    }

    public static RpgData get(ServerPlayerEntity p) { return state(p.getServer()).get(p.getUuid()); }

    /** One-time: permanent trait + perk by weighted rarity. Never called again for the same player. */
    public static void initialize(ServerPlayerEntity p, RpgData d) {
        Random rnd = ThreadLocalRandom.current();
        Trait t = Rarity.pick(Trait.values(), rnd);
        Perk perk = Rarity.pick(Perk.values(), rnd);
        d.traitId = t.id();
        d.perkId = perk.id();
        d.equip = EquipmentBonuses.compute(p);
        d.energy = d.maxEnergy();
        d.syncDirty = true;
    }

    public static void sync(ServerPlayerEntity p, int openPage) {
        RpgData d = get(p);
        long now = p.getServerWorld().getTime();
        ServerPlayNetworking.send(p, new SyncPayload(d.toSync(now).toString(), openPage));
        d.syncDirty = false;
    }

    /** Re-derive attributes + clamp energy + rank, then push to the client. */
    public static void refresh(ServerPlayerEntity p, RpgData d, boolean healGain, int openPage) {
        StatApplier.apply(p, d, healGain);
        checkRank(p, d, true);
        sync(p, openPage);
    }

    public static void checkRank(ServerPlayerEntity p, RpgData d, boolean announce) {
        Rank r = Rank.forProgress(d.level, d.kills);
        if (r.ordinal() > d.rankIdx) {
            d.rankIdx = r.ordinal();
            d.syncDirty = true;
            if (announce) {
                p.sendMessage(Text.literal("RANK UP! You are now ").formatted(Formatting.GOLD)
                        .append(Text.literal(r.icon + " " + r.label).formatted(r.color, Formatting.BOLD)), false);
                p.playSoundToPlayer(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 1f, 1f);
            }
        }
    }

    public static void award(ServerPlayerEntity p, RpgData d, long amount) {
        if (amount <= 0) return;
        int gained = d.addExp(amount);
        if (gained > 0) {
            p.sendMessage(Text.literal("LEVEL UP! Level " + d.level + "  (+" + (gained * RpgData.POINTS_PER_LEVEL)
                    + " stat points, " + d.points + " available)").formatted(Formatting.GOLD, Formatting.BOLD), false);
            p.playSoundToPlayer(SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1f, 1f);
        } else if (d.level < RpgData.MAX_LEVEL) {
            p.sendMessage(Text.literal("+" + amount + " EXP  (" + d.exp + "/" + d.expRequired() + ")")
                    .formatted(Formatting.GREEN), true);
        }
        checkRank(p, d, true);
        d.syncDirty = true;
    }
}
