package com.realmforge.logic;

import com.realmforge.data.RpgData;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

/** Pushes derived stats into vanilla attributes. Uses fixed-id TEMPORARY modifiers: replaced, never stacked. */
public final class StatApplier {
    private static final Identifier HP_ID = Identifier.of("realmforge", "vit_health");
    private static final Identifier SPEED_ID = Identifier.of("realmforge", "agi_speed");

    private StatApplier() { }

    public static void apply(ServerPlayerEntity p, RpgData d, boolean healGain) {
        float oldMax = p.getMaxHealth();
        float oldMaxEnergy = d.maxEnergy();
        set(p.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH), HP_ID,
                d.maxHealthBonus(), EntityAttributeModifier.Operation.ADD_VALUE);
        set(p.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED), SPEED_ID,
                d.speedBonus(), EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        float newMax = p.getMaxHealth();
        if (healGain && newMax > oldMax) p.heal(newMax - oldMax);
        float newMaxEnergy = d.maxEnergy();
        if (healGain && newMaxEnergy > oldMaxEnergy) d.energy = Math.min(newMaxEnergy, d.energy + (newMaxEnergy - oldMaxEnergy));
        if (p.getHealth() > newMax) p.setHealth(newMax);
        d.energy = Math.min(d.energy, d.maxEnergy());
        d.syncDirty = true;
    }

    private static void set(EntityAttributeInstance inst, Identifier id, double value, EntityAttributeModifier.Operation op) {
        if (inst == null) return;
        inst.removeModifier(id);
        if (value != 0) inst.addTemporaryModifier(new EntityAttributeModifier(id, value, op));
    }
}
