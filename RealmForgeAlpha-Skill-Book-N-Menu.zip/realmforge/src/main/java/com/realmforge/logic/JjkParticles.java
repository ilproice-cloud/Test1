package com.realmforge.logic;

import com.realmforge.RealmForgeMod;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/** Particle type IDs backed by the original ProjectJJK particle sprite sheets. */
public final class JjkParticles {
    private JjkParticles() {}

    public static final SimpleParticleType BLOOM = register("bloom");
    public static final SimpleParticleType SPARK = register("spark");
    public static final SimpleParticleType BF_SPARK = register("bf_spark");
    public static final SimpleParticleType RED_BOOM = register("red_boom");
    public static final SimpleParticleType PURPLE_BOOM = register("purple_boom");
    public static final SimpleParticleType BLUE_SPARK = register("blue_spark");
    public static final SimpleParticleType RED_SPARK = register("red_spark");
    public static final SimpleParticleType PURPLE_SPARK = register("purple_spark");
    public static final SimpleParticleType CE_SPARK = register("ce_spark");
    public static final SimpleParticleType BLOOD_SPLASH = register("blood_splash");

    private static SimpleParticleType register(String name) {
        return Registry.register(Registries.PARTICLE_TYPE, Identifier.of(RealmForgeMod.MOD_ID, name), FabricParticleTypes.simple(true));
    }
}
