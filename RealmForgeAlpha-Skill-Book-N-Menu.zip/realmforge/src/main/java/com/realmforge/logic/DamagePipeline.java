package com.realmforge.logic;

import com.realmforge.RpgManager;
import com.realmforge.data.RpgData;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;

/** Called from LivingEntityMixin at the head of LivingEntity#damage (server side only). */
public final class DamagePipeline {
    /** Set while a skill deals its (already fully scaled) damage, so it isn't scaled twice. */
    public static final ThreadLocal<Boolean> SKILL = ThreadLocal.withInitial(() -> false);

    private DamagePipeline() { }

    public static float modify(LivingEntity victim, DamageSource src, float amount) {
        if (victim.getWorld().isClient || amount <= 0) return amount;
        float a = amount;
        Entity attacker = src.getAttacker();

        if (attacker instanceof ServerPlayerEntity ap && attacker != victim && !SKILL.get()) {
            RpgData d = RpgManager.get(ap);
            double m = d.dmgOut();
            boolean physical = src.getSource() == attacker || src.isIn(DamageTypeTags.IS_PROJECTILE);
            if (physical) m *= d.physMult();
            a *= (float) m;
            double ls = d.lifesteal();
            if (ls > 0) ap.heal((float) (a * ls));
        }
        if (victim instanceof ServerPlayerEntity vp) {
            a *= (float) RpgManager.get(vp).dmgIn();
        }
        return a;
    }
}
