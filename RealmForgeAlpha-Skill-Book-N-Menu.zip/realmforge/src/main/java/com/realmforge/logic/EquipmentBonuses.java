package com.realmforge.logic;

import com.realmforge.data.Stat;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * PLACEHOLDER equipment table (edit freely). Bonuses are RE-COMPUTED from scratch from what the player
 * wears/holds, never accumulated, so they can't duplicate. An item only counts in its correct slot.
 */
public final class EquipmentBonuses {
    private EquipmentBonuses() { }

    public static int[] compute(ServerPlayerEntity p) {
        int[] r = new int[Stat.values().length];
        armor(r, p.getEquippedStack(EquipmentSlot.HEAD), "_helmet");
        armor(r, p.getEquippedStack(EquipmentSlot.CHEST), "_chestplate");
        armor(r, p.getEquippedStack(EquipmentSlot.LEGS), "_leggings");
        armor(r, p.getEquippedStack(EquipmentSlot.FEET), "_boots");
        mainHand(r, path(p.getEquippedStack(EquipmentSlot.MAINHAND)));
        offHand(r, path(p.getEquippedStack(EquipmentSlot.OFFHAND)));
        return r;
    }

    private static String path(ItemStack s) { return s.isEmpty() ? "" : Registries.ITEM.getId(s.getItem()).getPath(); }
    private static void add(int[] r, Stat s, int v) { r[s.ordinal()] += v; }

    private static void armor(int[] r, ItemStack st, String suffix) {
        String p = path(st);
        if (!p.endsWith(suffix)) return;
        if (p.startsWith("leather_")) add(r, Stat.AGI, 1);
        else if (p.startsWith("chainmail_")) { add(r, Stat.AGI, 1); add(r, Stat.VIT, 1); }
        else if (p.startsWith("iron_")) add(r, Stat.VIT, 1);
        else if (p.startsWith("golden_")) { add(r, Stat.ENE, 1); add(r, Stat.INT, 1); }
        else if (p.startsWith("diamond_")) add(r, Stat.VIT, 2);
        else if (p.startsWith("netherite_")) { add(r, Stat.VIT, 2); add(r, Stat.STR, 1); }
        else if (p.startsWith("turtle_")) add(r, Stat.ENE, 1);
    }

    private static int tier(String p) {
        if (p.startsWith("netherite_")) return 4;
        if (p.startsWith("diamond_")) return 3;
        if (p.startsWith("iron_")) return 2;
        return 1; // wooden, stone, golden
    }

    private static void mainHand(int[] r, String p) {
        if (p.isEmpty()) return;
        if (p.endsWith("_sword") || p.endsWith("_axe")) add(r, Stat.STR, tier(p));
        else switch (p) {
            case "bow", "crossbow" -> { add(r, Stat.AGI, 2); add(r, Stat.STR, 1); }
            case "trident" -> add(r, Stat.STR, 3);
            case "mace" -> add(r, Stat.STR, 4);
            case "blaze_rod" -> { add(r, Stat.INT, 3); add(r, Stat.ENE, 1); }
            case "breeze_rod" -> { add(r, Stat.INT, 4); add(r, Stat.AGI, 1); }
            default -> { }
        }
    }

    private static void offHand(int[] r, String p) {
        switch (p) {
            case "shield" -> add(r, Stat.VIT, 2);
            case "totem_of_undying" -> { add(r, Stat.ENE, 2); add(r, Stat.VIT, 1); }
            case "enchanted_book" -> add(r, Stat.INT, 1);
            default -> { }
        }
    }
}
