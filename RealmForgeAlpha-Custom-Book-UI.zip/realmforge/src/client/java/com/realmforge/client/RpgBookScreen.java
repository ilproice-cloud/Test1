package com.realmforge.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.BookScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Unified RealmForge book. All book pages stay inside the same vanilla page-turning screen. */
public class RpgBookScreen extends BookScreen {
    private static final Identifier BOOK_TEXTURE = Identifier.of("realmforge", "textures/gui/rpg_book_background.png");
    private static final float NORMAL_BOOK_SCALE = 1.0f;
    private float bookScale = NORMAL_BOOK_SCALE;
    private final int startPage;

    public RpgBookScreen(BookScreen.Contents contents, int startPage) {
        super(contents);
        this.startPage = startPage;
    }

    @Override
    protected void init() {
        super.init();
        // Keep the vanilla book at its normal size when possible, and shrink it
        // automatically when the current screen cannot fit the full book.
        float availableWidthScale = Math.max(0.1f, (this.width - 24.0f) / 192.0f);
        float availableHeightScale = Math.max(0.1f, (this.height - 24.0f) / 192.0f);
        this.bookScale = Math.min(NORMAL_BOOK_SCALE,
                Math.min(availableWidthScale, availableHeightScale));
        // Remove the vanilla Done button without touching page-turn controls.
        this.children().removeIf(element -> element instanceof ButtonWidget button
                && (button.getMessage().getString().equalsIgnoreCase("Done")
                    || button.getMessage().getString().equalsIgnoreCase("gui.done")));
        // Dedicated close control in the top-right corner; Escape also closes via Screen.
        this.addDrawableChild(ButtonWidget.builder(Text.literal("×"), button -> this.close())
                .dimensions(this.width - 28, 6, 20, 20).build());
        if (startPage > 0) this.setPage(startPage);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.getMatrices().push();
        ctx.getMatrices().translate(this.width / 2.0, this.height / 2.0, 0);
        ctx.getMatrices().scale(bookScale, bookScale, 1.0f);
        ctx.getMatrices().translate(-this.width / 2.0, -this.height / 2.0, 0);
        super.render(ctx, (int) Math.round(unscaleX(mouseX)), (int) Math.round(unscaleY(mouseY)), delta);
        ctx.getMatrices().pop();
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Keep Minecraft's darkened world background but do not add a blur shader.
        // Draw the custom open-book artwork instead of Minecraft's vanilla book.
        // BookScreen lays out text and page-turn buttons in a 192x192 coordinate area,
        // so the artwork uses that same destination rectangle to keep every control aligned.
        ctx.fill(0, 0, this.width, this.height, 0xB0000000);
        int x = (this.width - 192) / 2;
        int y = (this.height - 192) / 2;
        ctx.drawTexture(BOOK_TEXTURE, x, y, 0.0f, 0.0f, 192, 192, 666, 375);
    }

    private double unscaleX(double x) { return (x - this.width / 2.0) / bookScale + this.width / 2.0; }
    private double unscaleY(double y) { return (y - this.height / 2.0) / bookScale + this.height / 2.0; }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return super.mouseClicked(unscaleX(mouseX), unscaleY(mouseY), button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        return super.mouseReleased(unscaleX(mouseX), unscaleY(mouseY), button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return super.mouseDragged(unscaleX(mouseX), unscaleY(mouseY), button,
                deltaX / bookScale, deltaY / bookScale);
    }

    @Override
    public void mouseMoved(double mouseX, double mouseY) {
        super.mouseMoved(unscaleX(mouseX), unscaleY(mouseY));
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return super.mouseScrolled(unscaleX(mouseX), unscaleY(mouseY), horizontalAmount, verticalAmount);
    }
}
