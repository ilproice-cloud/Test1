package com.realmforge;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.realmforge.data.*;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class RpgCommands {
    private RpgCommands() { }

    private static final SuggestionProvider<ServerCommandSource> STAT_SUGGEST = (c, b) ->
            CommandSource.suggestMatching(Arrays.stream(Stat.values()).map(Stat::id).toList(), b);
    private static final SuggestionProvider<ServerCommandSource> SKILL_SUGGEST = (c, b) ->
            CommandSource.suggestMatching(Arrays.stream(Skill.values()).map(Skill::id).toList(), b);
    private static final SuggestionProvider<ServerCommandSource> TRAIT_SUGGEST = (c, b) ->
            CommandSource.suggestMatching(Arrays.stream(Trait.values()).map(Trait::id).toList(), b);
    private static final SuggestionProvider<ServerCommandSource> PERK_SUGGEST = (c, b) ->
            CommandSource.suggestMatching(Arrays.stream(Perk.values()).map(Perk::id).toList(), b);

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("realmforge")
                .executes(c -> openBook(c.getSource()))
                .then(literal("book").executes(c -> openBook(c.getSource())))
                .then(literal("stats").executes(c -> stats(c.getSource())))
                // /realmforge stat <stat> [amount]   (chat use, does not reopen the book)
                .then(literal("stat").then(argument("stat", StringArgumentType.word()).suggests(STAT_SUGGEST)
                        .executes(c -> spend(c, 1, false))
                        .then(argument("amount", IntegerArgumentType.integer(1, 10000)).executes(c -> spend(c, IntegerArgumentType.getInteger(c, "amount"), false)))))
                // /realmforge ui upgrade <stat> [amount]   (clicked from the book, reopens it on page 2)
                .then(literal("ui")
                        .then(literal("upgrade").then(argument("stat", StringArgumentType.word()).suggests(STAT_SUGGEST)
                                .executes(c -> spend(c, 1, true))
                                .then(argument("amount", IntegerArgumentType.integer(1, 10000)).executes(c -> spend(c, IntegerArgumentType.getInteger(c, "amount"), true)))))
                        .then(literal("traits").executes(c -> openUiPage(c.getSource(), -2)))
                        .then(literal("perks").executes(c -> openUiPage(c.getSource(), -3)))
                        .then(literal("information").executes(c -> openUiPage(c.getSource(), 5))))
                .then(literal("skill")
                        .then(literal("list").executes(c -> skillList(c.getSource())))
                        .then(literal("use").then(argument("slot", IntegerArgumentType.integer(1, Skill.SLOTS)).executes(c -> {
                            ServerPlayerEntity p = c.getSource().getPlayer();
                            if (p == null) return 0;
                            com.realmforge.logic.SkillExecutor.use(p, IntegerArgumentType.getInteger(c, "slot") - 1);
                            return 1;
                        })))
                        .then(literal("bind").then(argument("slot", IntegerArgumentType.integer(1, Skill.SLOTS))
                                .then(argument("skill", StringArgumentType.word()).suggests(SKILL_SUGGEST).executes(RpgCommands::bind)))))
                .then(admin()));
    }

    // ---------------- player commands ----------------

    private static int openBook(ServerCommandSource src) {
        ServerPlayerEntity p = src.getPlayer();
        if (p == null) return 0;
        RpgManager.sync(p, 0);
        return 1;
    }

    private static int openUiPage(ServerCommandSource src, int page) {
        ServerPlayerEntity p = src.getPlayer();
        if (p == null) return 0;
        RpgManager.sync(p, page);
        return 1;
    }

    private static int spend(CommandContext<ServerCommandSource> c, int amount, boolean ui) {
        ServerCommandSource src = c.getSource();
        ServerPlayerEntity p = src.getPlayer();
        if (p == null) { src.sendError(Text.literal("Players only.")); return 0; }
        Stat s = Stat.byId(StringArgumentType.getString(c, "stat"));
        if (s == null) { src.sendError(Text.literal("Unknown stat. Use str, agi, vit, int or ene.")); return 0; }
        RpgData d = RpgManager.get(p);
        if (!d.spend(s, amount)) {
            src.sendError(Text.literal("Not enough stat points (you have " + d.points + ")."));
            if (ui) RpgManager.sync(p, 1);
            return 0;
        }
        RpgManager.refresh(p, d, true, ui ? 1 : -1);
        if (!ui) msg(src, Text.literal("+" + amount + " " + s.abbr + " (now " + d.stat(s) + "), " + d.points + " points left.").formatted(Formatting.GREEN));
        return 1;
    }

    private static int stats(ServerCommandSource src) {
        ServerPlayerEntity p = src.getPlayer();
        if (p == null) return 0;
        RpgData d = RpgManager.get(p);
        Rank r = d.rank();
        msg(src, Text.literal("== " + p.getName().getString() + " ==").formatted(Formatting.GOLD));
        msg(src, Text.literal(r.icon + " " + r.label + "  Lv." + d.level + "  EXP " + d.exp + "/" + d.expRequired() + "  Points " + d.points).formatted(r.color));
        Trait t = d.trait(); Perk pk = d.perk();
        if (t != null) msg(src, Text.literal("Trait: " + t.displayName() + " (" + t.rarity().label + ")").formatted(t.rarity().color));
        if (pk != null) msg(src, Text.literal("Perk: " + pk.displayName() + " (" + pk.rarity().label + ")").formatted(pk.rarity().color));
        StringBuilder sb = new StringBuilder();
        for (Stat s : Stat.values()) sb.append(s.abbr).append(' ').append(d.stat(s)).append("   ");
        msg(src, Text.literal(sb.toString()).formatted(Formatting.YELLOW));
        msg(src, Text.literal(String.format("HP %.0f/%.0f   Energy %.0f/%.0f (+%.1f/s)", p.getHealth(), p.getMaxHealth(), d.energy, d.maxEnergy(), d.regenPerSecond())).formatted(Formatting.AQUA));
        return 1;
    }

    private static int skillList(ServerCommandSource src) {
        ServerPlayerEntity p = src.getPlayer();
        if (p == null) return 0;
        RpgData d = RpgManager.get(p);
        for (Skill s : Skill.values()) {
            boolean open = d.level >= s.unlockLevel;
            msg(src, Text.literal((open ? "" : "[Lv " + s.unlockLevel + "] ") + s.label + "  cost " + s.energyCost + "  cd " + (s.cooldownTicks / 20) + "s  skill lv " + d.skillLevel(s) + " - " + s.desc)
                    .formatted(open ? Formatting.GREEN : Formatting.DARK_GRAY));
        }
        for (int i = 0; i < Skill.SLOTS; i++) msg(src, Text.literal("Slot " + (i + 1) + ": " + d.slots[i]).formatted(Formatting.GRAY));
        return 1;
    }

    private static int bind(CommandContext<ServerCommandSource> c) {
        ServerCommandSource src = c.getSource();
        ServerPlayerEntity p = src.getPlayer();
        if (p == null) return 0;
        Skill s = Skill.byId(StringArgumentType.getString(c, "skill"));
        if (s == null) { src.sendError(Text.literal("Unknown skill.")); return 0; }
        RpgData d = RpgManager.get(p);
        if (d.level < s.unlockLevel) { src.sendError(Text.literal(s.label + " unlocks at level " + s.unlockLevel + ".")); return 0; }
        d.slots[IntegerArgumentType.getInteger(c, "slot") - 1] = s.id();
        d.syncDirty = true;
        RpgManager.sync(p, -1);
        msg(src, Text.literal("Bound " + s.label + " to slot " + IntegerArgumentType.getInteger(c, "slot") + ".").formatted(Formatting.GREEN));
        return 1;
    }

    // ---------------- admin commands (permission level 2) ----------------

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<ServerCommandSource> admin() {
        return literal("admin").requires(s -> s.hasPermissionLevel(2))
                .then(literal("setlevel").then(argument("player", EntityArgumentType.player())
                        .then(argument("level", IntegerArgumentType.integer(1, RpgData.MAX_LEVEL)).executes(c -> {
                            ServerPlayerEntity t = EntityArgumentType.getPlayer(c, "player");
                            RpgData d = RpgManager.get(t);
                            int lvl = IntegerArgumentType.getInteger(c, "level");
                            d.points = Math.max(0, d.points + RpgData.POINTS_PER_LEVEL * (lvl - d.level));
                            d.level = lvl; d.exp = 0;
                            return done(c, t, d, "Set level to " + lvl);
                        }))))
                .then(literal("addexp").then(argument("player", EntityArgumentType.player())
                        .then(argument("amount", IntegerArgumentType.integer(1)).executes(c -> {
                            ServerPlayerEntity t = EntityArgumentType.getPlayer(c, "player");
                            RpgData d = RpgManager.get(t);
                            RpgManager.award(t, d, IntegerArgumentType.getInteger(c, "amount"));
                            return done(c, t, d, "Added EXP");
                        }))))
                .then(literal("addpoints").then(argument("player", EntityArgumentType.player())
                        .then(argument("amount", IntegerArgumentType.integer(1, 100000)).executes(c -> {
                            ServerPlayerEntity t = EntityArgumentType.getPlayer(c, "player");
                            RpgData d = RpgManager.get(t);
                            d.points += IntegerArgumentType.getInteger(c, "amount");
                            return done(c, t, d, "Added points");
                        }))))
                .then(literal("respec").then(argument("player", EntityArgumentType.player()).executes(c -> {
                    ServerPlayerEntity t = EntityArgumentType.getPlayer(c, "player");
                    RpgData d = RpgManager.get(t);
                    Arrays.fill(d.base, 0);
                    d.points = RpgData.STARTING_POINTS + RpgData.POINTS_PER_LEVEL * (d.level - 1);
                    return done(c, t, d, "Respecced stats (trait/perk untouched)");
                })))
                .then(literal("settrait").then(argument("player", EntityArgumentType.player())
                        .then(argument("trait", StringArgumentType.word()).suggests(TRAIT_SUGGEST).executes(c -> {
                            Trait tr = Trait.byId(StringArgumentType.getString(c, "trait"));
                            if (tr == null) { c.getSource().sendError(Text.literal("Unknown trait.")); return 0; }
                            ServerPlayerEntity t = EntityArgumentType.getPlayer(c, "player");
                            RpgData d = RpgManager.get(t);
                            d.traitId = tr.id();
                            // Re-apply all derived attributes immediately after command changes.
                            return done(c, t, d, "Trait set to " + tr.displayName());
                        }))))
                .then(literal("setperk").then(argument("player", EntityArgumentType.player())
                        .then(argument("perk", StringArgumentType.word()).suggests(PERK_SUGGEST).executes(c -> {
                            Perk pk = Perk.byId(StringArgumentType.getString(c, "perk"));
                            if (pk == null) { c.getSource().sendError(Text.literal("Unknown perk.")); return 0; }
                            ServerPlayerEntity t = EntityArgumentType.getPlayer(c, "player");
                            RpgData d = RpgManager.get(t);
                            d.perkId = pk.id();
                            // Re-apply all derived attributes immediately after command changes.
                            return done(c, t, d, "Perk set to " + pk.displayName());
                        }))))
                .then(literal("reroll").then(argument("player", EntityArgumentType.player()).executes(c -> {
                    // Only way to get a new trait/perk: an operator, on purpose.
                    ServerPlayerEntity t = EntityArgumentType.getPlayer(c, "player");
                    RpgData d = RpgManager.get(t);
                    RpgManager.initialize(t, d);
                    return done(c, t, d, "Rerolled trait + perk");
                })))
                .then(literal("wipe").then(argument("player", EntityArgumentType.player()).executes(c -> {
                    ServerPlayerEntity t = EntityArgumentType.getPlayer(c, "player");
                    RpgManager.state(t.getServer()).remove(t.getUuid());
                    RpgData d = RpgManager.get(t);
                    RpgManager.initialize(t, d);
                    return done(c, t, d, "Wiped all RPG data and rolled a new trait/perk");
                })))
                .then(literal("simulate").then(argument("count", IntegerArgumentType.integer(1000, 1000000)).executes(c -> {
                    int n = IntegerArgumentType.getInteger(c, "count");
                    Random rnd = ThreadLocalRandom.current();
                    int[] traitHits = new int[Rarity.values().length], perkHits = new int[Rarity.values().length];
                    for (int i = 0; i < n; i++) {
                        traitHits[Rarity.pick(Trait.values(), rnd).rarity().ordinal()]++;
                        perkHits[Rarity.pick(Perk.values(), rnd).rarity().ordinal()]++;
                    }
                    for (Rarity r : Rarity.values()) {
                        String line = String.format("%-10s expected %5.2f%%  trait %5.2f%%  perk %5.2f%%", r.label, r.chancePercent(),
                                100.0 * traitHits[r.ordinal()] / n, 100.0 * perkHits[r.ordinal()] / n);
                        msg(c.getSource(), Text.literal(line).formatted(r.color));
                    }
                    return 1;
                })));
    }

    private static int done(CommandContext<ServerCommandSource> c, ServerPlayerEntity t, RpgData d, String what) throws CommandSyntaxException {
        RpgManager.refresh(t, d, false, -1);
        msg(c.getSource(), Text.literal(what + " for " + t.getName().getString() + ".").formatted(Formatting.GREEN));
        return 1;
    }

    private static void msg(ServerCommandSource src, Text t) { src.sendFeedback(() -> t, false); }
}
