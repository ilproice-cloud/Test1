package com.realmforge.net;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client request for free, cooldown-free healing magic. */
public record HealingMagicPayload(int request) implements CustomPayload {
    public static final Id<HealingMagicPayload> ID = new Id<>(Identifier.of("realmforge", "healing_magic"));
    public static final PacketCodec<ByteBuf, HealingMagicPayload> CODEC =
            PacketCodecs.INTEGER.xmap(HealingMagicPayload::new, HealingMagicPayload::request);
    @Override public Id<? extends CustomPayload> getId() { return ID; }
}
