package com.realmforge.logic;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Free, cooldown-free self-heal with a green magical aura. */
public final class HealingMagicExecutor {
    private HealingMagicExecutor() { }

    public static void use(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        float missing = player.getMaxHealth() - player.getHealth();
        if (missing > 0.01f) player.heal(Math.min(6.0f, missing));
        // Vanilla Glowing outline is white; green particles create the requested green glow aura.
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 30, 0, true, false, true));
        world.spawnParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getY() + 1.0, player.getZ(), 36, 0.48, 0.7, 0.48, 0.03);
        world.spawnParticles(ParticleTypes.WAX_ON, player.getX(), player.getY() + 0.9, player.getZ(), 18, 0.35, 0.55, 0.35, 0.02);
        world.spawnParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.5, player.getZ(), 5, 0.3, 0.35, 0.3, 0.02);
        world.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME,
                SoundCategory.PLAYERS, 0.65f, 1.65f);
        player.sendMessage(Text.literal("Healing Magic ✦").formatted(Formatting.GREEN), true);
    }
}
