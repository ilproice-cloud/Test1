package com.realmforge.logic;

import com.realmforge.RpgManager;
import com.realmforge.data.RpgData;
import com.realmforge.data.Skill;
import com.realmforge.data.Stat;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Server-authoritative temporary melee skills inspired by Project JJK's three moves. */
public final class SkillExecutor {
    private SkillExecutor() {}

    public static void use(ServerPlayerEntity p, int slot) {
        if (slot < 0 || slot >= Skill.SLOTS) return;
        RpgData d = RpgManager.get(p);
        Skill s = Skill.byId(d.slots[slot]);
        if (s == null) { bar(p, "No melee skill bound to slot " + (slot + 1), Formatting.GRAY); return; }
        if (d.level < s.unlockLevel) { bar(p, s.label + " unlocks at level " + s.unlockLevel, Formatting.RED); return; }

        long now = p.getServerWorld().getTime();
        long left = d.cdEnd[s.ordinal()] - now;
        if (left > 0) { bar(p, s.label + " ready in " + String.format("%.1fs", left / 20.0), Formatting.GRAY); return; }

        LivingEntity target = findTarget(p, s == Skill.BARRAGE ? 4.2 : 3.6);
        if (target == null) { bar(p, "No target in front of you", Formatting.GRAY); return; }

        boolean success = switch (s) {
            case STRONG_PUNCH -> strongPunch(p, d, target);
            case UPPERCUT -> uppercut(p, d, target);
            case BARRAGE -> barrage(p, d, target);
        };
        if (!success) return;
        d.skillUses[s.ordinal()]++;
        d.cdEnd[s.ordinal()] = now + s.cooldownTicks;
        d.syncDirty = true;
        RpgManager.sync(p, -1);
    }

    private static void bar(ServerPlayerEntity p, String msg, Formatting f) {
        p.sendMessage(Text.literal(msg).formatted(f), true);
    }

    private static LivingEntity findTarget(ServerPlayerEntity p, double range) {
        ServerWorld w = p.getServerWorld();
        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1.0f);
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(range, 2.0, range),
                x -> x != p && x.isAlive() && !x.isSpectator() && x.isAttackable())) {
            Vec3d to = e.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist > range || dist < 0.01 || to.normalize().dotProduct(look) < 0.45) continue;
            if (dist < bestDist) { bestDist = dist; best = e; }
        }
        return best;
    }

    private static double baseDamage(RpgData d, double base) {
        return (base + 0.6 * d.stat(Stat.STR)) * d.physMult() * d.skillBonus();
    }

    private static void hit(ServerPlayerEntity p, LivingEntity target, double damage) {
        DamagePipeline.SKILL.set(true);
        try { target.damage(p.getServerWorld().getDamageSources().playerAttack(p), (float) damage); }
        finally { DamagePipeline.SKILL.set(false); }
    }

    private static boolean strongPunch(ServerPlayerEntity p, RpgData d, LivingEntity target) {
        ServerWorld w = p.getServerWorld();
        p.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        boolean critical = w.random.nextInt(100) < 10;
        hit(p, target, baseDamage(d, 8.0) * (critical ? 3.0 : 1.0));
        Vec3d c = target.getBoundingBox().getCenter();
        w.spawnParticles(ParticleTypes.CRIT, c.x, c.y, c.z, 22, 0.35, 0.35, 0.35, 0.22);
        w.spawnParticles(ParticleTypes.SWEEP_ATTACK, c.x, c.y, c.z, 2, 0.15, 0.15, 0.15, 0);
        if (critical) {
            w.spawnParticles(ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
            bar(p, "BLACK FLASH!", Formatting.DARK_RED);
        }
        w.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_STRONG,
                SoundCategory.PLAYERS, 1.0f, critical ? 0.65f : 0.9f);
        knockAway(p, target, 0.45, 0.12);
        return true;
    }

    private static boolean uppercut(ServerPlayerEntity p, RpgData d, LivingEntity target) {
        ServerWorld w = p.getServerWorld();
        p.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        hit(p, target, baseDamage(d, 6.0));
        target.setVelocity(target.getVelocity().x, 0.9, target.getVelocity().z);
        target.velocityModified = true;
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20, 3, true, false, true));
        Vec3d c = target.getBoundingBox().getCenter();
        w.spawnParticles(ParticleTypes.CRIT, c.x, c.y, c.z, 18, 0.3, 0.35, 0.3, 0.2);
        w.spawnParticles(ParticleTypes.CLOUD, target.getX(), target.getY(), target.getZ(), 12, 0.3, 0.1, 0.3, 0.08);
        w.spawnParticles(ParticleTypes.SWEEP_ATTACK, c.x, c.y, c.z, 3, 0.2, 0.2, 0.2, 0);
        w.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK,
                SoundCategory.PLAYERS, 1.0f, 0.8f);
        return true;
    }

    private static boolean barrage(ServerPlayerEntity p, RpgData d, LivingEntity target) {
        ServerWorld w = p.getServerWorld();
        // Fifteen quick impact bursts/damage pulses, matching the reference move's hit count.
        for (int i = 0; i < 15 && target.isAlive(); i++) {
            p.swingHand(net.minecraft.util.Hand.MAIN_HAND);
            hit(p, target, baseDamage(d, 1.45));
            double ox = (w.random.nextDouble() - 0.5) * 0.75;
            double oy = w.random.nextDouble() * 1.2;
            double oz = (w.random.nextDouble() - 0.5) * 0.75;
            w.spawnParticles(ParticleTypes.CRIT, target.getX() + ox, target.getY() + oy, target.getZ() + oz,
                    3, 0.12, 0.12, 0.12, 0.12);
            if (i % 3 == 0) w.spawnParticles(ParticleTypes.SWEEP_ATTACK,
                    target.getX(), target.getY() + 0.8, target.getZ(), 1, 0.2, 0.2, 0.2, 0);
        }
        w.spawnParticles(ParticleTypes.CLOUD, target.getX(), target.getY() + 0.8, target.getZ(), 16, 0.45, 0.35, 0.45, 0.06);
        w.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP,
                SoundCategory.PLAYERS, 1.0f, 1.15f);
        knockAway(p, target, 0.3, 0.05);
        return true;
    }

    private static void knockAway(ServerPlayerEntity p, LivingEntity target, double strength, double y) {
        Vec3d dir = target.getPos().subtract(p.getPos());
        if (dir.horizontalLengthSquared() > 1.0E-4) {
            dir = new Vec3d(dir.x, 0, dir.z).normalize().multiply(strength);
            target.setVelocity(dir.x, Math.max(target.getVelocity().y, y), dir.z);
            target.velocityModified = true;
        }
    }
}
