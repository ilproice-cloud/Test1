package com.realmforge.logic;

import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Free Earth Spikes ability, cast with Z. All damage and particles are server-authoritative. */
public final class EarthSpikeExecutor {
    private static final int COOLDOWN_TICKS = 12;
    private static final double DAMAGE = 8.0;
    private static final Map<UUID, Long> NEXT_CAST = new ConcurrentHashMap<>();

    private EarthSpikeExecutor() { }

    public static void use(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        long now = world.getTime();
        long next = NEXT_CAST.getOrDefault(player.getUuid(), 0L);
        if (now < next) return;
        NEXT_CAST.put(player.getUuid(), now + COOLDOWN_TICKS);

        Vec3d look = player.getRotationVec(1.0f);
        Vec3d forward = new Vec3d(look.x, 0, look.z);
        if (forward.lengthSquared() < 1.0E-5) {
            double yaw = Math.toRadians(player.getYaw());
            forward = new Vec3d(-Math.sin(yaw), 0, Math.cos(yaw));
        }
        forward = forward.normalize();
        Vec3d side = new Vec3d(-forward.z, 0, forward.x);
        BlockStateParticleEffect stoneDust = new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.STONE.getDefaultState());
        BlockStateParticleEffect dirtDust = new BlockStateParticleEffect(ParticleTypes.BLOCK, Blocks.DIRT.getDefaultState());

        // Five jagged rows of rising stone shards in front of the caster.
        for (int row = 1; row <= 5; row++) {
            double distance = 1.25 + row * 0.85;
            Vec3d center = player.getPos().add(forward.multiply(distance));
            for (int shard = -2; shard <= 2; shard++) {
                Vec3d point = center.add(side.multiply(shard * 0.62));
                BlockPos ground = BlockPos.ofFloored(point.x, player.getY(), point.z);
                while (ground.getY() > world.getBottomY() && world.getBlockState(ground).isAir()) ground = ground.down();
                if (ground.getY() <= world.getBottomY()) continue;
                double height = 0.7 + ((row + shard + 5) % 3) * 0.25;
                double x = ground.getX() + 0.5, z = ground.getZ() + 0.5, y = ground.getY() + 1.0;
                world.spawnParticles(stoneDust, x, y + height * 0.45, z, 12, 0.18, height * 0.35, 0.18, 0.12);
                world.spawnParticles(dirtDust, x, y, z, 5, 0.2, 0.08, 0.2, 0.06);
                world.spawnParticles(ParticleTypes.CRIT, x, y + height, z, 3, 0.12, 0.18, 0.12, 0.08);
            }
        }

        // Damage living targets caught in the forward spike lane; no energy is consumed.
        Vec3d origin = player.getPos();
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class,
                player.getBoundingBox().stretch(forward.multiply(6.0)).expand(1.7, 0.5, 1.7),
                e -> e != player && e.isAlive() && !e.isSpectator())) {
            Vec3d delta = target.getBoundingBox().getCenter().subtract(origin);
            Vec3d horizontal = new Vec3d(delta.x, 0, delta.z);
            double distance = horizontal.length();
            if (distance < 1.0 || distance > 6.5) continue;
            if (horizontal.normalize().dotProduct(forward) < 0.72) continue;
            DamagePipeline.SKILL.set(true);
            try { target.damage(world.getDamageSources().playerAttack(player), (float) DAMAGE); }
            finally { DamagePipeline.SKILL.set(false); }
            target.addVelocity(forward.x * 0.35, 0.28, forward.z * 0.35);
            target.velocityModified = true;
        }

        world.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BLOCK_STONE_BREAK,
                SoundCategory.PLAYERS, 1.1f, 0.65f);
        world.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ENTITY_IRON_GOLEM_ATTACK,
                SoundCategory.PLAYERS, 0.7f, 0.55f);
        player.sendMessage(Text.literal("Earth Spikes! ").formatted(Formatting.GREEN)
                .append(Text.literal("(no energy cost)").formatted(Formatting.GRAY)), true);
    }
}
