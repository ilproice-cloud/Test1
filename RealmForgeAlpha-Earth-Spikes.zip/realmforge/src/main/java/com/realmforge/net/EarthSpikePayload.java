package com.realmforge.net;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client request to cast the free Earth Spikes ability. */
public record EarthSpikePayload(int request) implements CustomPayload {
    public static final Id<EarthSpikePayload> ID = new Id<>(Identifier.of("realmforge", "earth_spike"));
    public static final PacketCodec<ByteBuf, EarthSpikePayload> CODEC =
            PacketCodecs.INTEGER.xmap(EarthSpikePayload::new, EarthSpikePayload::request);

    @Override public Id<? extends CustomPayload> getId() { return ID; }
}
