package com.realmforge.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Custom responsive two-page RealmForge book; deliberately does not use vanilla BookScreen. */
public final class RpgBookScreen extends Screen {
    private static final Identifier BOOK_TEXTURE = Identifier.of("realmforge", "textures/gui/rpg_book_background.png");
    private static final int ART_W = 463, ART_H = 301;
    private final List<Text> pages;
    private int firstPage;
    private int bookX, bookY, bookW, bookH;
    private float scale;

    public RpgBookScreen(List<Text> pages, int startPage) {
        super(Text.literal("RealmForge"));
        this.pages = new ArrayList<>(pages);
        this.firstPage = clampFirstPage(startPage);
    }

    @Override protected void init() {
        this.clearChildren();
        // Fit the full open-book artwork inside the screen without stretching its aspect ratio.
        float sx = (this.width - 116.0f) / ART_W;
        float sy = (this.height - 36.0f) / ART_H;
        // The texture is cropped to the actual paper edges, so it can fill the screen better.
        // Cap scale for readable text while preserving the artwork's aspect ratio.
        scale = Math.max(0.25f, Math.min(1.8f, Math.min(sx, sy)));
        bookW = Math.max(1, Math.round(ART_W * scale));
        bookH = Math.max(1, Math.round(ART_H * scale));
        bookX = (this.width - bookW) / 2;
        bookY = Math.max(4, (this.height - bookH) / 2);
        int buttonW = Math.max(24, Math.round(34 * scale));
        int buttonH = Math.max(18, Math.round(20 * scale));
        int buttonY = Math.max(2, Math.min(this.height - buttonH - 2, bookY + bookH / 2 - buttonH / 2));
        // Custom close control only. No vanilla Done button is created or rendered.
        addDrawableChild(ButtonWidget.builder(Text.literal("×"), b -> close())
                .dimensions(Math.min(this.width - buttonW - 2, bookX + bookW - buttonW), Math.max(2, bookY - buttonH + 2), buttonW, buttonH).build());
        // Place arrows at the left/right outside edges, vertically centered beside the book.
        int sideGap = Math.max(4, Math.round(10 * scale));
        int leftX = Math.max(2, bookX - buttonW - sideGap);
        int rightX = Math.min(this.width - buttonW - 2, bookX + bookW + sideGap);
        // On narrow phone layouts, keep the controls visible just inside the book edges.
        if (leftX + buttonW > bookX) leftX = Math.max(2, bookX + sideGap);
        if (rightX < bookX + bookW) rightX = Math.min(this.width - buttonW - 2, bookX + bookW - buttonW - sideGap);
        addDrawableChild(ButtonWidget.builder(Text.literal("‹"), b -> { firstPage = Math.max(0, firstPage - 2); refreshPageButtons(); })
                .dimensions(leftX, buttonY, buttonW, buttonH).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("›"), b -> { firstPage = Math.min(Math.max(0, pages.size() - 1), firstPage + 2); refreshPageButtons(); })
                .dimensions(rightX, buttonY, buttonW, buttonH).build());
        refreshPageButtons();
    }

    private int clampFirstPage(int requested) {
        // Keep the first page on an even index so the book always shows a left/right pair.
        int maxFirst = Math.max(0, ((pages.size() - 1) / 2) * 2);
        return Math.max(0, Math.min(requested, maxFirst));
    }

    private void refreshPageButtons() {
        firstPage = clampFirstPage(firstPage);
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // No blur and no dark overlay: leave the world crisp behind the custom book.
        ctx.drawTexture(BOOK_TEXTURE, bookX, bookY, 0, 0, bookW, bookH, ART_W, ART_H);
        // Draw text in the same cropped-art coordinate space as the artwork so font and
        // page layout scale together on phones and desktop screens.
        ctx.getMatrices().push();
        ctx.getMatrices().translate(bookX, bookY, 0);
        ctx.getMatrices().scale(scale, scale, 1.0f);
        drawPage(ctx, firstPage, 20, 40, 185, 12);
        drawPage(ctx, firstPage + 1, 248, 40, 185, 12);
        ctx.getMatrices().pop();
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawPage(DrawContext ctx, int index, int x, int y, int maxWidth, int lineHeight) {
        if (index < 0 || index >= pages.size()) return;
        // The entire book and its text share the same responsive scale. This keeps glyphs
        // sharp and much larger than the previous double-scaled text on mobile screens.
        List<OrderedText> lines = textRenderer.wrapLines(pages.get(index), maxWidth);
        int maxLines = 19;
        int drawn = 0;
        for (OrderedText line : lines) {
            if (drawn >= maxLines) break;
            ctx.drawText(textRenderer, line, x, y + drawn * lineHeight, 0xFF292018, false);
            drawn++;
        }
        ctx.drawText(textRenderer, Text.literal(String.valueOf(index + 1)).formatted(Formatting.DARK_GRAY),
                x + maxWidth / 2 - 2, 282, 0xFF6B6256, false);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // Intentionally empty: do not invoke Minecraft's blurred menu background.
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (keyCode == GLFW.GLFW_KEY_LEFT) { firstPage = clampFirstPage(firstPage - 2); return true; }
        if (keyCode == GLFW.GLFW_KEY_RIGHT) { firstPage = clampFirstPage(firstPage + 2); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean shouldPause() { return false; }
}
