package com.realmforge.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Custom responsive two-page RealmForge book; deliberately does not use vanilla BookScreen. */
public final class RpgBookScreen extends Screen {
    private static final Identifier BOOK_TEXTURE = Identifier.of("realmforge", "textures/gui/rpg_book_background.png");
    private static final int ART_W = 666, ART_H = 375;
    private final List<Text> pages;
    private int firstPage;
    private int bookX, bookY, bookW, bookH, pageWidth;
    private float scale;

    public RpgBookScreen(List<Text> pages, int startPage) {
        super(Text.literal("RealmForge"));
        this.pages = new ArrayList<>(pages);
        this.firstPage = Math.max(0, Math.min(startPage, Math.max(0, pages.size() - 1)));
    }

    @Override protected void init() {
        this.clearChildren();
        // Fit the full open-book artwork inside the screen without stretching its aspect ratio.
        float sx = (this.width - 24.0f) / ART_W;
        float sy = (this.height - 42.0f) / ART_H;
        scale = Math.max(0.25f, Math.min(1.0f, Math.min(sx, sy)));
        bookW = Math.max(1, Math.round(ART_W * scale));
        bookH = Math.max(1, Math.round(ART_H * scale));
        bookX = (this.width - bookW) / 2;
        bookY = Math.max(20, (this.height - bookH) / 2);
        pageWidth = Math.round(ART_W * 0.39f * scale);
        int buttonY = Math.min(this.height - 24, bookY + bookH - Math.round(30 * scale));
        int buttonW = Math.max(24, Math.round(34 * scale));
        int buttonH = Math.max(18, Math.round(20 * scale));
        // Close button; no Done button is created anywhere in this screen.
        addDrawableChild(ButtonWidget.builder(Text.literal("×"), b -> close())
                .dimensions(bookX + bookW - buttonW - 4, Math.max(2, bookY - buttonH - 2), buttonW, buttonH).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("‹"), b -> { firstPage = Math.max(0, firstPage - 2); refreshPageButtons(); })
                .dimensions(bookX + Math.round(10 * scale), buttonY, buttonW, buttonH).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("›"), b -> { firstPage = Math.min(Math.max(0, pages.size() - 1), firstPage + 2); refreshPageButtons(); })
                .dimensions(bookX + bookW - buttonW - Math.round(10 * scale), buttonY, buttonW, buttonH).build());
        refreshPageButtons();
    }

    private void refreshPageButtons() {
        // Arrow callbacks clamp page index. init() rebuilds the controls when the window resizes.
        firstPage = Math.max(0, Math.min(firstPage, Math.max(0, pages.size() - 1)));
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xB0000000);
        ctx.drawTexture(BOOK_TEXTURE, bookX, bookY, 0, 0, bookW, bookH, ART_W, ART_H);
        // Draw text in the same 666x375 coordinate space as the artwork so font and
        // page layout scale together on phones and desktop screens.
        ctx.getMatrices().push();
        ctx.getMatrices().translate(bookX, bookY, 0);
        ctx.getMatrices().scale(scale, scale, 1.0f);
        drawPage(ctx, firstPage, 123, 67, 185, 10);
        drawPage(ctx, firstPage + 1, 350, 67, 185, 10);
        ctx.getMatrices().pop();
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawPage(DrawContext ctx, int index, int x, int y, int maxWidth, int lineHeight) {
        if (index < 0 || index >= pages.size()) return;
        List<OrderedText> lines = textRenderer.wrapLines(pages.get(index), maxWidth);
        int maxLines = 24;
        int drawn = 0;
        for (OrderedText line : lines) {
            if (drawn >= maxLines) break;
            ctx.drawText(textRenderer, line, x, y + drawn * lineHeight, 0xFF292018, false);
            drawn++;
        }
        ctx.drawText(textRenderer, Text.literal(String.valueOf(index + 1)).formatted(Formatting.DARK_GRAY),
                x + maxWidth / 2 - 2, 319, 0xFF6B6256, false);
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (keyCode == GLFW.GLFW_KEY_LEFT) { firstPage = Math.max(0, firstPage - 2); return true; }
        if (keyCode == GLFW.GLFW_KEY_RIGHT) { firstPage = Math.min(Math.max(0, pages.size() - 1), firstPage + 2); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean shouldPause() { return false; }
}
