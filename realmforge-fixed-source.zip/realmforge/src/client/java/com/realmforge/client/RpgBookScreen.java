package com.realmforge.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.BookScreen;
import net.minecraft.util.Identifier;

/**
 * Single vanilla book screen for every RealmForge page. Use the normal GUI scale so text and
 * page controls share the same coordinates and remain usable on small screens.
 */
public class RpgBookScreen extends BookScreen {
    private static final Identifier BOOK_TEXTURE = Identifier.ofVanilla("textures/gui/book.png");

    private final int startPage;

    public RpgBookScreen(BookScreen.Contents contents, int startPage) {
        super(contents);
        this.startPage = startPage;
    }

    @Override
    protected void init() {
        super.init();
        if (startPage > 0) this.setPage(startPage);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderInGameBackground(ctx);                      // plain dim, no blur
        int x = (this.width - 192) / 2;
        ctx.drawTexture(BOOK_TEXTURE, x, 2, 0, 0, 192, 192);
    }

}
