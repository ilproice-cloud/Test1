package com.realmforge.client;

import com.realmforge.data.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.*;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * One unified book: player, attributes, stat effects, references, bars, then all trait and perk entries.
 * Trait and perk information is part of the same page-turning book, not separate screens.
 */
public final class RpgBook {
    private static final int PER_PAGE = 2;
    private static final int BAR_LEN = 22;
    private RpgBook() { }

    // ------------------------------------------------------------------ entry points
    // Main book has exactly six pages. Trait/perk catalogues are opened only from Information.
    public static Screen screen(int startPage) {
        if (startPage == -2) return catalogue(true);
        if (startPage == -3) return catalogue(false);
        return main(startPage);
    }

    public static Screen main(int startPage) {
        RpgData d = ClientRpg.data;
        List<Text> pages = new ArrayList<>();
        pages.add(playerPage(d, playerName()));
        pages.add(attributesPage(d));
        pages.add(effectsPage(d));
        pages.add(referencesPage(d));
        pages.add(statsBarsPage(d));
        pages.add(informationPage(d));
        return make(pages, startPage);
    }

    private static Screen catalogue(boolean traits) {
        RpgData d = ClientRpg.data;
        List<Text> pages = new ArrayList<>();
        passivePages(pages, traits ? "TRAITS" : "PERKS", traits ? Trait.values() : Perk.values(), traits ? d.traitId : d.perkId);
        return make(pages, 0);
    }

    private static Text informationPage(RpgData d) {
        MutableText m = Text.empty();
        m.append(t("INFORMATION\n\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        m.append(t("View every available trait and its effects.\n", Formatting.GRAY));
        m.append(button("[ TRAITS ]", "/realmforge ui traits", Formatting.DARK_PURPLE, "Open the trait catalogue"));
        m.append(t("\n\n", Formatting.BLACK));
        m.append(t("View every available perk and its effects.\n", Formatting.GRAY));
        m.append(button("[ PERKS ]", "/realmforge ui perks", Formatting.DARK_AQUA, "Open the perk catalogue"));
        m.append(t("\n\nYour assigned trait and perk are permanent.", Formatting.DARK_GRAY));
        return m;
    }

    private static Screen make(List<Text> pages, int startPage) {
        return new RpgBookScreen(pages, startPage);
    }

    private static String playerName() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player != null ? mc.player.getName().getString() : "Player";
    }

    // ------------------------------------------------------------------ Page 1 - Player
    private static Text playerPage(RpgData d, String name) {
        Rank r = d.rank();
        Trait tr = d.trait(); Perk pk = d.perk();
        MutableText m = Text.empty();
        m.append(t("PLAYER\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        m.append(t("[" + r.icon + "] " + name + "\n", Formatting.BOLD, Formatting.BLACK));
        m.append(t("Rank: ", Formatting.DARK_GRAY)).append(t(r.label + "\n", Formatting.BOLD, r.bookColor));
        m.append(t("Level: ", Formatting.DARK_GRAY)).append(t(d.level + "\n", Formatting.BLACK));
        m.append(t("EXP: ", Formatting.DARK_GRAY)).append(t(d.level >= RpgData.MAX_LEVEL ? "MAX\n" : d.exp + " / " + d.expRequired() + "\n", Formatting.BLACK));
        Rank nx = r.next();
        if (nx != null) m.append(t("Next: " + nx.label + " (Lv" + nx.minLevel + ", " + nx.minKills + " kills; you: " + d.kills + ")\n", Formatting.GRAY));
        m.append(t("\nTrait: ", Formatting.DARK_GRAY));
        if (tr != null) m.append(t(tr.displayName(), tr.rarity().bookColor, Formatting.BOLD)).append(t(" (" + tr.rarity().label + ")\n", tr.rarity().bookColor));
        m.append(t("Perk: ", Formatting.DARK_GRAY));
        if (pk != null) m.append(t(pk.displayName(), pk.rarity().bookColor, Formatting.BOLD)).append(t(" (" + pk.rarity().label + ")\n", pk.rarity().bookColor));
        m.append(t("\nStat points: ", Formatting.DARK_GRAY)).append(t(String.valueOf(d.points), d.points > 0 ? Formatting.DARK_GREEN : Formatting.BLACK, Formatting.BOLD));
        return m;
    }

    // ------------------------------------------------------------------ Page 2 - Attributes (bars + buttons)
    private static Text attributesPage(RpgData d) {
        int cap = Math.max(10, RpgData.STARTING_POINTS + RpgData.POINTS_PER_LEVEL * (d.level - 1));
        MutableText m = Text.empty();
        m.append(t("ATTRIBUTES\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        for (Stat s : Stat.values()) {
            int v = d.stat(s), bonus = d.bonusOf(s);
            m.append(t(s.abbr + " " + v + " ", Formatting.BOLD, s.bookColor));
            if (d.points >= 1) m.append(button("[+1]", "/realmforge ui upgrade " + s.id() + " 1", s.bookColor, "Spend 1 point on " + s.label));
            else m.append(t("[+1]", Formatting.GRAY));
            m.append(Text.literal(" "));
            if (d.points >= 5) m.append(button("[+5]", "/realmforge ui upgrade " + s.id() + " 5", s.bookColor, "Spend 5 points on " + s.label));
            else m.append(t("[+5]", Formatting.GRAY));
            m.append(Text.literal("\n"));

            int filled = Math.round(Math.min(1f, v / (float) cap) * BAR_LEN);
            m.append(t("|".repeat(filled), s.bookColor));
            m.append(t("|".repeat(BAR_LEN - filled), Formatting.GRAY));
            if (bonus != 0) m.append(t(" " + (bonus > 0 ? "+" : "") + bonus, bonus > 0 ? Formatting.DARK_GREEN : Formatting.DARK_RED));
            m.append(Text.literal("\n"));
        }
        m.append(t("Points left: ", Formatting.DARK_GRAY)).append(t(String.valueOf(d.points), d.points > 0 ? Formatting.DARK_GREEN : Formatting.BLACK, Formatting.BOLD));
        return m;
    }

    // ------------------------------------------------------------------ Page 3 - Stat effects (all five, compact)
    private static Text effectsPage(RpgData d) {
        MutableText m = Text.empty();
        m.append(t("STAT EFFECTS\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        m.append(t("Per-point gains / current totals\n", Formatting.GRAY));
        m.append(t("STR  +2% physical damage/pt / current +" + pct(d.physMult() - 1) + "\n", Stat.STR.bookColor));
        m.append(t("AGI  +1% speed/pt; +0.5% dodge/pt\n", Stat.AGI.bookColor));
        m.append(t("     Current speed +" + pct(d.speedBonus()) + ", dodge " + pct(d.dodge()) + "\n", Stat.AGI.bookColor));
        m.append(t("VIT  +4 max HP/pt; total +" + d.maxHealthBonus() + " HP\n", Stat.VIT.bookColor));
        m.append(t("INT  +3% skill/magic damage/pt; total +" + pct(d.intSkillMult() - 1) + "\n", Stat.INT.bookColor));
        m.append(t("ENE  +10 max energy/pt; total " + (int)d.maxEnergy() + "\n", Stat.ENE.bookColor));
        m.append(t("     Energy regen: " + String.format(Locale.ROOT, "%.1f", d.regenPerSecond()) + "/sec\n\n", Stat.ENE.bookColor));
        m.append(t("YOUR TRAIT + PERK\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        appendPassiveEffects(m, d.trait());
        appendPassiveEffects(m, d.perk());
        return m;
    }

    private static void appendPassiveEffects(MutableText m, Passive passive) {
        if (passive == null) return;
        List<String> buffs = passive.effects().buffs();
        List<String> debuffs = passive.effects().debuffs();
        m.append(t(passive.displayName() + ": ", Formatting.BOLD, passive.rarity().bookColor));
        m.append(t(buffs.isEmpty() ? "Buffs none" : "+ " + String.join(", ", buffs), Formatting.DARK_GREEN));
        if (!debuffs.isEmpty()) m.append(t(" / - " + String.join(", ", debuffs), Formatting.DARK_RED));
        m.append(Text.literal("\n"));
    }

    private static void head(MutableText m, Stat s, RpgData d) {
        m.append(t(s.abbr + " " + d.stat(s) + "\n", Formatting.BOLD, s.bookColor));
    }
    private static void body(MutableText m, Stat s, String text) {
        m.append(t(text + "\n", s.bookColor));
    }

    // ------------------------------------------------------------------ Page 4 - References hub
    private static Text referencesPage(RpgData d) {
        Trait tr = d.trait(); Perk pk = d.perk();
        MutableText m = Text.empty();
        m.append(t("REFERENCES\n\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        m.append(t("Use the Information page to browse all traits and perks.\n\n", Formatting.DARK_AQUA));
        m.append(t("Your trait:\n", Formatting.DARK_GRAY));
        if (tr != null) m.append(t(tr.displayName() + " (" + tr.rarity().label + ")\n\n", tr.rarity().bookColor, Formatting.BOLD));
        m.append(t("Your perk:\n", Formatting.DARK_GRAY));
        if (pk != null) m.append(t(pk.displayName() + " (" + pk.rarity().label + ")\n\n", pk.rarity().bookColor, Formatting.BOLD));
        m.append(t("Both are permanent.", Formatting.GRAY));
        return m;
    }

    // ------------------------------------------------------------------ Page 5 - Stats in Bars
    private static Text statsBarsPage(RpgData d) {
        MutableText m = Text.empty();
        m.append(t("STATS IN BARS\n\n", Formatting.BOLD, Formatting.DARK_PURPLE));
        int maxHp = Math.max(1, 20 + d.maxHealthBonus());
        int hp = MinecraftClient.getInstance().player == null ? maxHp : Math.round(MinecraftClient.getInstance().player.getHealth());
        bar(m, "Health (HP)", Math.max(0, hp), maxHp, Formatting.RED);
        float maxEnergy = d.maxEnergy();
        bar(m, "Energy (CE)", Math.round(d.energy), Math.max(1, Math.round(maxEnergy)), Formatting.AQUA);
        long required = Math.max(1, d.expRequired());
        bar(m, "EXP (EXP)", d.level >= RpgData.MAX_LEVEL ? required : d.exp, required, Formatting.YELLOW);
        m.append(t("\nLVL " + d.level + "   Points " + d.points, Formatting.DARK_GRAY));
        return m;
    }

    private static void bar(MutableText m, String label, long current, long max, Formatting color) {
        int safeMax = (int)Math.max(1, Math.min(Integer.MAX_VALUE, max));
        int safeCurrent = (int)Math.max(0, Math.min(safeMax, current));
        int filled = Math.round((safeCurrent / (float)safeMax) * BAR_LEN);
        m.append(t(label + ": " + safeCurrent + "/" + safeMax + "\n", Formatting.BOLD, color));
        m.append(t("|".repeat(filled), color));
        m.append(t("|".repeat(BAR_LEN - filled), Formatting.GRAY));
        m.append(Text.literal("\n\n"));
    }

    // ------------------------------------------------------------------ Trait / Perk lists
    private static void passivePages(List<Text> pages, String title, Passive[] all, String selectedId) {
        int count = (int) Math.ceil(all.length / (double) PER_PAGE);
        for (int pg = 0; pg < count; pg++) {
            MutableText m = Text.empty();
            m.append(t(title + " " + (pg + 1) + "/" + count + "\n", Formatting.BOLD, Formatting.DARK_PURPLE));
            m.append(button("[ BACK TO INFORMATION ]", "/realmforge ui information", Formatting.BLUE, "Return to the Information page"));
            m.append(t("\n\n", Formatting.GRAY));
            for (int i = pg * PER_PAGE; i < Math.min(all.length, (pg + 1) * PER_PAGE); i++) {
                Passive p = all[i];
                boolean mine = p.id().equalsIgnoreCase(selectedId);
                MutableText head = t((mine ? "\u2605 " : "") + p.displayName() + " (" + p.rarity().label + ")",
                        p.rarity().bookColor, Formatting.BOLD);
                if (mine) head.formatted(Formatting.UNDERLINE);
                m.append(head).append(Text.literal("\n"));
                m.append(t(p.description() + "\n", Formatting.GRAY));
                List<String> buffs = p.effects().buffs(), debuffs = p.effects().debuffs();
                if (!buffs.isEmpty()) m.append(t(String.join(", ", buffs) + "\n", Formatting.DARK_GREEN));
                if (!debuffs.isEmpty()) m.append(t(String.join(", ", debuffs) + "\n", Formatting.DARK_RED));
                if (mine) m.append(t("<< YOURS (permanent)\n", Formatting.GOLD, Formatting.BOLD));
                m.append(Text.literal("\n"));
            }
            pages.add(m);
        }
    }

    // ------------------------------------------------------------------ helpers
    private static String pct(double v) {
        double p = v * 100;
        return (Math.abs(p - Math.round(p)) < 0.05 ? String.valueOf(Math.round(p)) : String.format(Locale.ROOT, "%.1f", p)) + "%";
    }

    private static MutableText t(String s, Formatting... f) { return Text.literal(s).formatted(f); }

    private static MutableText button(String label, String command, Formatting color, String hover) {
        return Text.literal(label).setStyle(Style.EMPTY.withColor(color).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, command))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal(hover))));
    }

}
