package com.realmforge.logic;

import com.realmforge.RpgManager;
import com.realmforge.data.RpgData;
import com.realmforge.data.Skill;
import com.realmforge.data.Stat;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

/** Server-authoritative temporary melee skills inspired by Project JJK's three moves. */
public final class SkillExecutor {
    private SkillExecutor() {}

    private static final Map<UUID, ActiveBarrage> ACTIVE_BARRAGES = new HashMap<>();

    private static final class ActiveBarrage {
        final ServerPlayerEntity player;
        final LivingEntity target;
        int hitsLeft = 15;
        long nextHitTick;
        final boolean originalNoGravity;
        ActiveBarrage(ServerPlayerEntity player, LivingEntity target, long now) {
            this.player = player;
            this.target = target;
            this.nextHitTick = now;
            this.originalNoGravity = target.hasNoGravity();
            // Hold the victim in place for the whole flurry so the follow-up combo connects.
            target.setNoGravity(true);
            target.setVelocity(Vec3d.ZERO);
            target.velocityModified = true;
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 10, true, false, true));
        }
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(SkillExecutor::tickBarrages);
    }

    private static void tickBarrages(MinecraftServer server) {
        Iterator<Map.Entry<UUID, ActiveBarrage>> it = ACTIVE_BARRAGES.entrySet().iterator();
        while (it.hasNext()) {
            ActiveBarrage b = it.next().getValue();
            if (!b.player.isAlive() || !b.target.isAlive() || b.player.getServer() != server) {
                releaseBarrageTarget(b);
                it.remove();
                continue;
            }
            // Re-lock movement and cancel all knockback while the barrage is active.
            b.target.setNoGravity(true);
            b.target.setVelocity(Vec3d.ZERO);
            b.target.velocityModified = true;
            b.target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 5, 10, true, false, true));
            long now = server.getTicks();
            if (now < b.nextHitTick) continue;
            b.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
            RpgData data = RpgManager.get(b.player);
            hit(b.player, b.target, baseDamage(data, 0.25));
            // Damage must not push the victim out of the combo window.
            b.target.setVelocity(Vec3d.ZERO);
            b.target.velocityModified = true;
            ServerWorld world = b.player.getServerWorld();
            double ox = (world.random.nextDouble() - 0.5) * 0.8;
            double oy = 0.25 + world.random.nextDouble() * Math.max(0.5, b.target.getHeight() - 0.25);
            double oz = (world.random.nextDouble() - 0.5) * 0.8;
            world.spawnParticles(JjkParticles.SPARK, b.target.getX() + ox, b.target.getY() + oy, b.target.getZ() + oz, 2, 0.08, 0.08, 0.08, 0.01);
            if (b.hitsLeft % 3 == 0) world.spawnParticles(JjkParticles.BLOOM, b.target.getX(), b.target.getY() + b.target.getHeight() * 0.55, b.target.getZ(), 1, 0.12, 0.12, 0.12, 0.0);
            b.hitsLeft--;
            b.nextHitTick = now + 2; // Original move is a timed flurry, not 15 hits on one tick.
            if (b.hitsLeft <= 0 || !b.target.isAlive()) {
                world.spawnParticles(JjkParticles.BLOOD_SPLASH, b.target.getX(), b.target.getY() + b.target.getHeight() * 0.5, b.target.getZ(), 3, 0.25, 0.3, 0.25, 0.02);
                world.spawnParticles(ParticleTypes.CLOUD, b.target.getX(), b.target.getY() + 0.8, b.target.getZ(), 8, 0.35, 0.25, 0.35, 0.04);
                world.playSound(null, b.target.getX(), b.target.getY(), b.target.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.0f, 1.15f);
                releaseBarrageTarget(b);
                it.remove();
            }
        }
    }

    public static void use(ServerPlayerEntity p, int slot) {
        if (slot < 0 || slot >= Skill.SLOTS) return;
        RpgData d = RpgManager.get(p);
        Skill s = Skill.byId(d.slots[slot]);
        if (s == null) { bar(p, "No melee skill bound to slot " + (slot + 1), Formatting.GRAY); return; }
        if (d.level < s.unlockLevel) { bar(p, s.label + " unlocks at level " + s.unlockLevel, Formatting.RED); return; }

        long now = p.getServerWorld().getTime();
        long left = d.cdEnd[s.ordinal()] - now;
        if (left > 0) { bar(p, s.label + " ready in " + String.format("%.1fs", left / 20.0), Formatting.GRAY); return; }

        LivingEntity target = findTarget(p, switch (s) { case STRONG_PUNCH -> 6.0; case UPPERCUT -> 4.0; case BARRAGE -> 5.0; });
        if (target == null) { bar(p, "No target in front of you", Formatting.GRAY); return; }

        boolean success = switch (s) {
            case STRONG_PUNCH -> strongPunch(p, d, target);
            case UPPERCUT -> uppercut(p, d, target);
            case BARRAGE -> startBarrage(p, target);
        };
        if (!success) return;
        d.skillUses[s.ordinal()]++;
        d.cdEnd[s.ordinal()] = now + s.cooldownTicks;
        d.syncDirty = true;
        RpgManager.sync(p, -1);
    }

    private static void bar(ServerPlayerEntity p, String msg, Formatting f) {
        p.sendMessage(Text.literal(msg).formatted(f), true);
    }

    private static LivingEntity findTarget(ServerPlayerEntity p, double range) {
        ServerWorld w = p.getServerWorld();
        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1.0f);
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(range, 2.0, range),
                x -> x != p && x.isAlive() && !x.isSpectator() && x.isAttackable())) {
            Vec3d to = e.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist > range || dist < 0.01 || to.normalize().dotProduct(look) < 0.45) continue;
            if (dist < bestDist) { bestDist = dist; best = e; }
        }
        return best;
    }

    private static double baseDamage(RpgData d, double base) {
        return (base + 0.6 * d.stat(Stat.STR)) * d.physMult() * d.skillBonus();
    }

    private static void hit(ServerPlayerEntity p, LivingEntity target, double damage) {
        DamagePipeline.SKILL.set(true);
        try { target.damage(p.getServerWorld().getDamageSources().playerAttack(p), (float) damage); }
        finally { DamagePipeline.SKILL.set(false); }
    }

    private static boolean strongPunch(ServerPlayerEntity p, RpgData d, LivingEntity target) {
        ServerWorld w = p.getServerWorld();
        p.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        // ProjectJJK Power Punch: 10% Black Flash chance; Black Flash multiplies damage by 3.
        boolean blackFlash = w.random.nextInt(100) < 10;
        hit(p, target, baseDamage(d, 1.5) * (blackFlash ? 3.0 : 1.0));
        Vec3d c = target.getBoundingBox().getCenter();
        w.spawnParticles(JjkParticles.SPARK, c.x, c.y, c.z, 6, 0.22, 0.25, 0.22, 0.02);
        w.spawnParticles(JjkParticles.BLOOM, c.x, c.y, c.z, 2, 0.12, 0.12, 0.12, 0.0);
        if (blackFlash) {
            w.spawnParticles(JjkParticles.BF_SPARK, c.x, c.y, c.z, 14, 0.32, 0.35, 0.32, 0.04);
            w.spawnParticles(JjkParticles.RED_BOOM, c.x, c.y, c.z, 1, 0, 0, 0, 0);
            w.spawnParticles(ParticleTypes.FLASH, c.x, c.y, c.z, 1, 0, 0, 0, 0);
            bar(p, "BLACK FLASH!", Formatting.DARK_RED);
        }
        w.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_STRONG,
                SoundCategory.PLAYERS, 1.0f, blackFlash ? 0.65f : 0.9f);
        knockAway(p, target, 0.45, 0.12);
        return true;
    }

    private static boolean uppercut(ServerPlayerEntity p, RpgData d, LivingEntity target) {
        ServerWorld w = p.getServerWorld();
        p.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        // ProjectJJK Uppercut uses a short forward raycast and launches the victim upward.
        hit(p, target, baseDamage(d, 0.5));
        Vec3d toward = target.getPos().subtract(p.getPos());
        if (toward.horizontalLengthSquared() > 1.0E-4) {
            toward = new Vec3d(toward.x, 0, toward.z).normalize();
        } else {
            toward = new Vec3d(-Math.sin(Math.toRadians(p.getYaw())), 0, Math.cos(Math.toRadians(p.getYaw())));
        }
        // Launch both fighters so the attacker can follow into an aerial combo.
        target.setVelocity(toward.x * 0.18, 0.9, toward.z * 0.18);
        target.velocityModified = true;
        p.setVelocity(toward.x * 0.42, 0.82, toward.z * 0.42);
        p.velocityModified = true;
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20, 3, true, false, true));
        Vec3d c = target.getBoundingBox().getCenter();
        w.spawnParticles(JjkParticles.SPARK, c.x, c.y, c.z, 9, 0.25, 0.35, 0.25, 0.025);
        w.spawnParticles(JjkParticles.BLOOM, c.x, c.y, c.z, 2, 0.15, 0.2, 0.15, 0.0);
        w.spawnParticles(JjkParticles.BLUE_SPARK, target.getX(), target.getY() + 0.5, target.getZ(), 4, 0.2, 0.35, 0.2, 0.03);
        w.spawnParticles(ParticleTypes.CLOUD, target.getX(), target.getY(), target.getZ(), 8, 0.3, 0.1, 0.3, 0.06);
        w.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK,
                SoundCategory.PLAYERS, 1.0f, 0.8f);
        return true;
    }

    private static boolean startBarrage(ServerPlayerEntity p, LivingEntity target) {
        ACTIVE_BARRAGES.put(p.getUuid(), new ActiveBarrage(p, target, p.getServer().getTicks()));
        p.getServerWorld().playSound(null, target.getX(), target.getY(), target.getZ(),
                SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 0.8f, 1.35f);
        return true;
    }

    private static void releaseBarrageTarget(ActiveBarrage barrage) {
        LivingEntity target = barrage.target;
        target.setNoGravity(barrage.originalNoGravity);
        target.setVelocity(Vec3d.ZERO);
        target.velocityModified = true;
        target.removeStatusEffect(StatusEffects.SLOWNESS);
    }

    private static void knockAway(ServerPlayerEntity p, LivingEntity target, double strength, double y) {
        Vec3d dir = target.getPos().subtract(p.getPos());
        if (dir.horizontalLengthSquared() > 1.0E-4) {
            dir = new Vec3d(dir.x, 0, dir.z).normalize().multiply(strength);
            target.setVelocity(dir.x, Math.max(target.getVelocity().y, y), dir.z);
            target.velocityModified = true;
        }
    }
}
