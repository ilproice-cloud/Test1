package com.realmforge.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Custom responsive two-page RealmForge book; deliberately does not use vanilla BookScreen. */
public final class RpgBookScreen extends Screen {
    private static final Identifier BOOK_TEXTURE = Identifier.of("realmforge", "textures/gui/rpg_book_background.png");
    private static final int ART_W = 463, ART_H = 301;
    private final List<Text> pages;
    private int firstPage;
    private int bookX, bookY, bookW, bookH;
    private float scale;
    private int closeButtonX, closeButtonY, closeButtonW, closeButtonH;
    private final boolean catalogueScreen;

    public RpgBookScreen(List<Text> pages, int startPage, boolean catalogueScreen) {
        super(Text.literal("RealmForge"));
        this.pages = new ArrayList<>(pages);
        this.firstPage = clampFirstPage(startPage);
        this.catalogueScreen = catalogueScreen;
    }

    @Override protected void init() {
        this.clearChildren();
        // Fit the full open-book artwork inside the screen without stretching its aspect ratio.
        float sx = (this.width - 116.0f) / ART_W;
        float sy = (this.height - 36.0f) / ART_H;
        // The texture is cropped to the actual paper edges, so it can fill the screen better.
        // Cap scale for readable text while preserving the artwork's aspect ratio.
        scale = Math.max(0.25f, Math.min(1.65f, Math.min(sx, sy)));
        bookW = Math.max(1, Math.round(ART_W * scale));
        bookH = Math.max(1, Math.round(ART_H * scale));
        bookX = (this.width - bookW) / 2;
        bookY = Math.max(4, (this.height - bookH) / 2);
        int buttonW = Math.max(24, Math.round(34 * scale));
        int buttonH = Math.max(18, Math.round(20 * scale));
        int buttonY = Math.max(2, Math.min(this.height - buttonH - 2, bookY + bookH / 2 - buttonH / 2));
        // Custom close control only. No vanilla Done button is created or rendered.
        int closeX = Math.min(this.width - buttonW - 2, bookX + bookW - buttonW);
        int closeY = Math.max(2, bookY - buttonH + 2);
        addDrawableChild(ButtonWidget.builder(Text.empty(), b -> close())
                .dimensions(closeX, closeY, buttonW, buttonH).build());
        closeButtonX = closeX; closeButtonY = closeY; closeButtonW = buttonW; closeButtonH = buttonH;
        // Place arrows at the left/right outside edges, vertically centered beside the book.
        int sideGap = Math.max(4, Math.round(10 * scale));
        int leftX = Math.max(2, bookX - buttonW - sideGap);
        int rightX = Math.min(this.width - buttonW - 2, bookX + bookW + sideGap);
        // On narrow phone layouts, keep the controls visible just inside the book edges.
        if (leftX + buttonW > bookX) leftX = Math.max(2, bookX + sideGap);
        if (rightX < bookX + bookW) rightX = Math.min(this.width - buttonW - 2, bookX + bookW - buttonW - sideGap);
        addDrawableChild(ButtonWidget.builder(Text.literal("‹"), b -> { firstPage = Math.max(0, firstPage - 2); refreshPageButtons(); })
                .dimensions(leftX, buttonY, buttonW, buttonH).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("›"), b -> { firstPage = Math.min(Math.max(0, pages.size() - 1), firstPage + 2); refreshPageButtons(); })
                .dimensions(rightX, buttonY, buttonW, buttonH).build());

        // Text drawn by DrawContext is not an interactive text widget. Use real buttons.
        if (catalogueScreen) {
            int bw = Math.max(76, Math.round(100 * scale));
            int bh = Math.max(18, Math.round(20 * scale));
            addDrawableChild(ButtonWidget.builder(Text.literal("‹ INFORMATION"), b ->
                    net.minecraft.client.MinecraftClient.getInstance().setScreen(RpgBook.main(5)))
                    .dimensions(bookX + Math.round(30 * scale), bookY + Math.round(48 * scale), bw, bh).build());
        } else {
            // Attribute upgrade controls are real widgets aligned over the inline labels.
            if (firstPage == 0) {
                String[] statIds = {"str", "agi", "vit", "int", "ene"};
                for (int i = 0; i < statIds.length; i++) {
                    final String statId = statIds[i];
                    int y = bookY + Math.round((48 + i * 20) * scale);
                    int x1 = bookX + Math.round(288 * scale);
                    int x5 = bookX + Math.round(318 * scale);
                    int bw = Math.max(23, Math.round(25 * scale));
                    int bh = Math.max(14, Math.round(10 * scale));
                    addDrawableChild(ButtonWidget.builder(Text.literal("+1"), b -> sendCommand("realmforge ui upgrade " + statId + " 1"))
                            .dimensions(x1, y, bw, bh).build());
                    addDrawableChild(ButtonWidget.builder(Text.literal("+5"), b -> sendCommand("realmforge ui upgrade " + statId + " 5"))
                            .dimensions(x5, y, bw, bh).build());
                }
            }
            // Information is page 6 (index 5), shown on the right page when firstPage == 4.
            if (firstPage == 4) {
                int bw = Math.max(64, Math.round(82 * scale));
                int bh = Math.max(18, Math.round(20 * scale));
                int x = bookX + Math.round(270 * scale);
                int y = bookY + Math.round(78 * scale);
                addDrawableChild(ButtonWidget.builder(Text.literal("TRAITS"), b ->
                        net.minecraft.client.MinecraftClient.getInstance().setScreen(RpgBook.screen(-2)))
                        .dimensions(x, y, bw, bh).build());
                addDrawableChild(ButtonWidget.builder(Text.literal("PERKS"), b ->
                        net.minecraft.client.MinecraftClient.getInstance().setScreen(RpgBook.screen(-3)))
                        .dimensions(x, y + bh + 5, bw, bh).build());
            }
        }
        refreshPageButtons();
    }

    private void sendCommand(String command) {
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        if (mc.player != null && mc.player.networkHandler != null) {
            mc.player.networkHandler.sendChatCommand(command);
        }
    }

    private int clampFirstPage(int requested) {
        // Keep the first page on an even index so the book always shows a left/right pair.
        int maxFirst = Math.max(0, ((pages.size() - 1) / 2) * 2);
        return Math.max(0, Math.min(requested, maxFirst));
    }

    private void refreshPageButtons() {
        firstPage = clampFirstPage(firstPage);
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // No blur and no dark overlay: leave the world crisp behind the custom book.
        // IMPORTANT: draw the texture at its real pixel size, then scale the matrix.
        // Passing bookW/bookH as the source-region size makes Minecraft tile the texture,
        // which caused duplicate books along the right and bottom edges.
        ctx.getMatrices().push();
        ctx.getMatrices().translate(bookX, bookY, 0);
        ctx.getMatrices().scale(scale, scale, 1.0f);
        ctx.drawTexture(BOOK_TEXTURE, 0, 0, 0, 0, ART_W, ART_H, ART_W, ART_H);
        // Text uses the same coordinate system as the artwork, so it stays on the paper.
        drawPage(ctx, firstPage, 30, 38, 185, 10);
        drawPage(ctx, firstPage + 1, 258, 38, 185, 10);
        ctx.getMatrices().pop();
        super.render(ctx, mouseX, mouseY, delta);
        // Small user-provided parchment X is the actual visible exit button.
        ctx.drawTexture(Identifier.of("realmforge", "textures/gui/exit_button.png"),
                closeButtonX, closeButtonY, 0, 0, closeButtonW, closeButtonH, 64, 64);
    }

    private void drawPage(DrawContext ctx, int index, int x, int y, int maxWidth, int lineHeight) {
        if (index < 0 || index >= pages.size()) return;
        // The entire book and its text share the same responsive scale. This keeps glyphs
        // sharp and much larger than the previous double-scaled text on mobile screens.
        List<OrderedText> lines = textRenderer.wrapLines(pages.get(index), maxWidth);
        int maxLines = 17;
        int drawn = 0;
        // Slightly reduce text size without changing the book art or its responsive scale.
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x, y, 0);
        ctx.getMatrices().scale(0.92f, 0.92f, 1.0f);
        for (OrderedText line : lines) {
            if (drawn >= maxLines) break;
            ctx.drawText(textRenderer, line, 0, drawn * lineHeight, 0xFF292018, false);
            drawn++;
        }
        // Page number sits higher, inside the lower margin of each paper page.
        ctx.drawText(textRenderer, Text.literal(String.valueOf(index + 1)).formatted(Formatting.DARK_GRAY),
                maxWidth / 2 - 2, 254, 0xFF6B6256, false);
        ctx.getMatrices().pop();
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // Intentionally empty: do not invoke Minecraft's blurred menu background.
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (keyCode == GLFW.GLFW_KEY_LEFT) { firstPage = clampFirstPage(firstPage - 2); return true; }
        if (keyCode == GLFW.GLFW_KEY_RIGHT) { firstPage = clampFirstPage(firstPage + 2); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean shouldPause() { return false; }
}
