package com.realmforge.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/** Custom responsive two-page RealmForge book; deliberately does not use vanilla BookScreen. */
public final class RpgBookScreen extends Screen {
    private static final Identifier BOOK_TEXTURE = Identifier.of("realmforge", "textures/gui/rpg_book_background.png");
    private static final int ART_W = 666, ART_H = 375;
    private final List<Text> pages;
    private int firstPage;
    private int bookX, bookY, bookW, bookH, pageWidth;
    private float scale;

    public RpgBookScreen(List<Text> pages, int startPage) {
        super(Text.literal("RealmForge"));
        this.pages = new ArrayList<>(pages);
        this.firstPage = Math.max(0, Math.min(startPage, Math.max(0, pages.size() - 1)));
    }

    @Override protected void init() {
        this.clearChildren();
        // Fit the full open-book artwork inside the screen without stretching its aspect ratio.
        float sx = (this.width - 32.0f) / ART_W;
        float sy = (this.height - 36.0f) / ART_H;
        // Keep the artwork crisp at native scale when possible; center it on every aspect ratio.
        scale = Math.max(0.25f, Math.min(1.0f, Math.min(sx, sy)));
        bookW = Math.max(1, Math.round(ART_W * scale));
        bookH = Math.max(1, Math.round(ART_H * scale));
        bookX = (this.width - bookW) / 2;
        bookY = Math.max(4, (this.height - bookH) / 2);
        pageWidth = Math.round(ART_W * 0.39f * scale);
        int buttonW = Math.max(24, Math.round(34 * scale));
        int buttonH = Math.max(18, Math.round(20 * scale));
        int buttonY = Math.max(2, Math.min(this.height - buttonH - 2, bookY + bookH / 2 - buttonH / 2));
        // Custom close control only. No vanilla Done button is created or rendered.
        addDrawableChild(ButtonWidget.builder(Text.literal("×"), b -> close())
                .dimensions(Math.min(this.width - buttonW - 2, bookX + bookW - buttonW), Math.max(2, bookY - buttonH + 2), buttonW, buttonH).build());
        // Put page arrows outside the left/right edges of the book, like familiar vanilla page controls.
        int sideGap = Math.max(2, Math.round(8 * scale));
        int leftX = Math.max(2, bookX - buttonW - sideGap);
        int rightX = Math.min(this.width - buttonW - 2, bookX + bookW + sideGap);
        addDrawableChild(ButtonWidget.builder(Text.literal("‹"), b -> { firstPage = Math.max(0, firstPage - 2); refreshPageButtons(); })
                .dimensions(leftX, buttonY, buttonW, buttonH).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("›"), b -> { firstPage = Math.min(Math.max(0, pages.size() - 1), firstPage + 2); refreshPageButtons(); })
                .dimensions(rightX, buttonY, buttonW, buttonH).build());
        refreshPageButtons();
    }

    private void refreshPageButtons() {
        // Arrow callbacks clamp page index. init() rebuilds the controls when the window resizes.
        firstPage = Math.max(0, Math.min(firstPage, Math.max(0, pages.size() - 1)));
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // No blur and no heavy black overlay: keep the world sharp behind the book.
        ctx.fill(0, 0, width, height, 0x30000000);
        ctx.drawTexture(BOOK_TEXTURE, bookX, bookY, 0, 0, bookW, bookH, ART_W, ART_H);
        // Draw text in the same 666x375 coordinate space as the artwork so font and
        // page layout scale together on phones and desktop screens.
        ctx.getMatrices().push();
        ctx.getMatrices().translate(bookX, bookY, 0);
        ctx.getMatrices().scale(scale, scale, 1.0f);
        drawPage(ctx, firstPage, 123, 67, 185, 10);
        drawPage(ctx, firstPage + 1, 350, 67, 185, 10);
        ctx.getMatrices().pop();
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawPage(DrawContext ctx, int index, int x, int y, int maxWidth, int lineHeight) {
        if (index < 0 || index >= pages.size()) return;
        // Enlarge the writing while keeping its line spacing and margins inside the paper.
        final float textScale = 1.35f;
        final int logicalWidth = Math.max(70, Math.round(maxWidth / textScale));
        List<OrderedText> lines = textRenderer.wrapLines(pages.get(index), logicalWidth);
        int maxLines = 23;
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x, y, 0);
        ctx.getMatrices().scale(textScale, textScale, 1.0f);
        int drawn = 0;
        for (OrderedText line : lines) {
            if (drawn >= maxLines) break;
            ctx.drawText(textRenderer, line, 0, Math.round(drawn * lineHeight / textScale), 0xFF292018, false);
            drawn++;
        }
        ctx.getMatrices().pop();
        ctx.drawText(textRenderer, Text.literal(String.valueOf(index + 1)).formatted(Formatting.DARK_GRAY),
                x + maxWidth / 2 - 2, 319, 0xFF6B6256, false);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // Intentionally empty: do not invoke Minecraft's blurred menu background.
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (keyCode == GLFW.GLFW_KEY_LEFT) { firstPage = Math.max(0, firstPage - 2); return true; }
        if (keyCode == GLFW.GLFW_KEY_RIGHT) { firstPage = Math.min(Math.max(0, pages.size() - 1), firstPage + 2); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean shouldPause() { return false; }
}
