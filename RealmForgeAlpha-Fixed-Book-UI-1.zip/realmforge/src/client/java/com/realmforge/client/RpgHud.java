package com.realmforge.client;

import com.realmforge.data.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class RpgHud {
    private RpgHud() { }

    public static void render(DrawContext g, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        RpgData d = ClientRpg.data;
        if (d == null || mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;

        int x = 8, y = 8;
        int w = Math.min(390, Math.max(180, mc.getWindow().getScaledWidth() - 16));
        int barH = 27; // 2.5x the previous 11px bar height
        int rowGap = 30;
        g.fill(x - 4, y - 4, x + w + 4, y + 154, 0x90000000);

        Rank r = d.rank();
        g.getMatrices().push();
        g.getMatrices().translate(x, y, 0);
        g.getMatrices().scale(1.35f, 1.35f, 1.0f);
        g.drawTextWithShadow(tr, Text.literal("[" + r.icon + "] " + mc.player.getName().getString()).formatted(r.color), 0, 0, 0xFFFFFF);
        Text lv = Text.literal("Lv." + d.level).formatted(Formatting.YELLOW);
        g.drawTextWithShadow(tr, lv, Math.max(110, (int)(w / 1.35f) - tr.getWidth(lv)), 0, 0xFFFFFF);
        g.drawTextWithShadow(tr, Text.literal(r.label).formatted(Formatting.GRAY), 0, 12, 0xFFFFFF);
        g.getMatrices().pop();
        if (d.points > 0) {
            Text pts = Text.literal("+" + d.points + " pts [K]").formatted(Formatting.GOLD);
            g.drawTextWithShadow(tr, pts, x + w - tr.getWidth(pts), y + 24, 0xFFFFFF);
        }
        y += 32;

        float hp = mc.player.getHealth(), maxHp = mc.player.getMaxHealth();
        bar(g, tr, x, y, w, barH, hp / Math.max(1f, maxHp), 0xFFC62828, String.format("HP %.0f / %.0f", hp, maxHp));
        y += rowGap;
        float maxE = d.maxEnergy();
        bar(g, tr, x, y, w, barH, d.energy / Math.max(1f, maxE), 0xFF1E78D2, String.format("EN %.0f / %.0f", d.energy, maxE));
        y += rowGap;
        boolean max = d.level >= RpgData.MAX_LEVEL;
        bar(g, tr, x, y, w, barH, max ? 1f : (float) d.exp / Math.max(1, d.expRequired()), 0xFF2E9E3F,
                max ? "EXP MAX" : "EXP " + d.exp + " / " + d.expRequired());
    }

    private static void bar(DrawContext g, TextRenderer tr, int x, int y, int w, int h, float frac, int color, String label) {
        frac = Math.max(0f, Math.min(1f, frac));
        g.fill(x, y, x + w, y + h, 0xFF1C1C1C);
        g.fill(x, y, x + (int) (w * frac), y + h, color);
        g.getMatrices().push();
        g.getMatrices().translate(x, y, 0);
        g.getMatrices().scale(1.35f, 1.35f, 1.0f);
        g.drawCenteredTextWithShadow(tr, Text.literal(label), (int)(w / 2.0f / 1.35f), Math.max(1, (int)(h / 2.0f / 1.35f - 4)), 0xFFFFFF);
        g.getMatrices().pop();
    }
}
